import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Phone, MessageCircle, ArrowRight, Star, Users, Award } from 'lucide-react';
import { Toaster, toast } from 'sonner';

import Navbar from './components/Navbar';
import Burger3D from './components/Burger3D';
import ParticleBackground from './components/ParticleBackground';
import MenuCard from './components/MenuCard';
import StarRating from './components/StarRating';
import CartModal from './components/CartModal';
import type { CartItem } from './components/CartModal';

import type { MenuItem } from './data/menu';
import { menuData } from './data/menu';
import type { Review } from './data/reviews';
import { initialReviews } from './data/reviews';

export default function StreetersBarGrill() {
  // Navigation
  const [activeSection, setActiveSection] = useState<'home' | 'menu' | 'reviews' | 'order'>('home');
  const [scrollProgress, setScrollProgress] = useState(0);

  // Cart State
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);

  // Reviews State
  const [reviews, setReviews] = useState<Review[]>(initialReviews);
  const [newReview, setNewReview] = useState({
    name: '',
    rating: 5,
    comment: '',
  });
  const [isSubmittingReview, setIsSubmittingReview] = useState(false);

  // Load cart from localStorage
  useEffect(() => {
    const savedCart = localStorage.getItem('streeters-cart');
    if (savedCart) {
      setCart(JSON.parse(savedCart));
    }
    const savedReviews = localStorage.getItem('streeters-reviews');
    if (savedReviews) {
      setReviews(JSON.parse(savedReviews));
    }
  }, []);

  // Save cart & reviews to localStorage
  useEffect(() => {
    localStorage.setItem('streeters-cart', JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem('streeters-reviews', JSON.stringify(reviews));
  }, [reviews]);

  // Scroll progress + active section
  useEffect(() => {
    const handleScroll = () => {
      const totalHeight = document.documentElement.scrollHeight - window.innerHeight;
      const progress = totalHeight > 0 ? (window.scrollY / totalHeight) * 100 : 0;
      setScrollProgress(Math.min(progress, 100));

      // Detect active section
      const sections = ['home', 'menu', 'reviews', 'order'];
      let current = 'home';

      for (const sectionId of sections) {
        const sectionEl = document.getElementById(sectionId);
        if (sectionEl) {
          const rect = sectionEl.getBoundingClientRect();
          if (rect.top <= 140) {
            current = sectionId as any;
          }
        }
      }
      setActiveSection(current as any);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Smooth scroll to section
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      const offset = 80;
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition - bodyRect - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth',
      });
    }
  };

  // Cart functions
  const addToCart = (item: MenuItem) => {
    setCart((prev) => {
      const existing = prev.findIndex((cartItem) => cartItem.id === item.id);
      if (existing !== -1) {
        const updated = [...prev];
        updated[existing] = {
          ...updated[existing],
          quantity: updated[existing].quantity + 1,
        };
        return updated;
      } else {
        return [...prev, { ...item, quantity: 1 }];
      }
    });

    toast.success(`${item.name} added to order`, {
      description: `$${item.price} • Tap cart to review`,
      action: {
        label: "View Cart",
        onClick: () => setIsCartOpen(true),
      },
    });
  };

  const updateCartQuantity = (id: number, newQuantity: number) => {
    if (newQuantity < 1) return;
    setCart((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, quantity: newQuantity } : item
      )
    );
  };

  const removeFromCart = (id: number) => {
    setCart((prev) => prev.filter((item) => item.id !== id));
  };

  const openCart = () => setIsCartOpen(true);
  const closeCart = () => setIsCartOpen(false);

  // Checkout simulation
  const handleCheckout = () => {
    const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
    const itemCount = cart.reduce((sum, item) => sum + item.quantity, 0);

    closeCart();

    setTimeout(() => {
      toast.success("Order confirmed!", {
        description: `${itemCount} items • $${total.toFixed(2)}. Our team will call you shortly.`,
      });
      
      // Simulate calling
      setTimeout(() => {
        toast("Calling Streeters now...", {
          description: "Thank you for ordering with us. See you soon!",
        });
      }, 1400);

      setCart([]); // Clear cart after "order"
    }, 420);
  };

  const handleWhatsAppOrder = () => {
    // The actual WhatsApp link is handled inside the modal
    // This just closes and gives feedback
    closeCart();
    toast.success("WhatsApp opened", {
      description: "Complete your order in the chat.",
    });
  };

  // Reviews
  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!newReview.name.trim() || !newReview.comment.trim()) {
      toast.error("Please fill out your name and review");
      return;
    }

    setIsSubmittingReview(true);

    const review: Review = {
      id: Date.now(),
      name: newReview.name.trim(),
      rating: newReview.rating,
      comment: newReview.comment.trim(),
      date: "Just now",
      avatar: newReview.name.trim().slice(0, 2).toUpperCase(),
    };

    // Add to top
    setReviews((prev) => [review, ...prev]);

    // Reset form
    setNewReview({ name: '', rating: 5, comment: '' });

    setTimeout(() => {
      setIsSubmittingReview(false);
      toast.success("Thank you for your review!", {
        description: "It has been added to our wall of fame.",
      });
    }, 650);
  };

  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="min-h-screen bg-brand-black text-white font-sans selection:bg-brand-orange/30">
      <Toaster position="top-center" richColors closeButton />

      {/* Scroll Progress Bar */}
      <div 
        className="scroll-progress fixed top-0 left-0 z-[110] h-0.5" 
        style={{ width: `${scrollProgress}%` }}
      />

      <Navbar 
        activeSection={activeSection} 
        onNavClick={scrollToSection} 
        cartCount={cartCount}
        onCartClick={openCart}
      />

      {/* ========== HOME / HERO ========== */}
      <section id="home" className="relative min-h-[100dvh] flex items-center justify-center pt-20 overflow-hidden neon-bg">
        {/* Animated Neon Particle Background */}
        <ParticleBackground />

        {/* Subtle grid overlay for futuristic feel */}
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.015)_1px,transparent_1px)] bg-[length:4px_4px] pointer-events-none z-[1]" />

        <div className="relative z-10 max-w-5xl mx-auto px-6 text-center">
          {/* Logo */}
          <div className="mb-8 flex justify-center">
            <div className="inline-flex flex-col items-center">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-brand-orange via-brand-yellow to-brand-orange flex items-center justify-center shadow-[0_0_40px_rgba(255,106,0,0.5)]">
                  <span className="text-[#0B0B0F] font-black text-5xl tracking-[-3px]">S</span>
                </div>
                <div className="text-left">
                  <div className="font-black text-[52px] md:text-[68px] leading-none tracking-[-3.5px] text-white">STREETERS</div>
                  <div className="text-brand-yellow text-xl md:text-2xl tracking-[6px] font-medium -mt-1">BAR_GRILL</div>
                </div>
              </div>
            </div>
          </div>

          <div className="max-w-3xl mx-auto">
            <p className="text-2xl md:text-[42px] leading-none font-semibold tracking-[-1.8px] cinematic-text mb-4">
              American Heat.<br />Street Flavor.
            </p>
            <p className="text-xl text-white/70 tracking-tight mb-10">
              A cinematic American Fast Food Experience
            </p>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16">
            <button 
              onClick={() => scrollToSection('menu')}
              className="btn-primary group flex items-center justify-center gap-3 px-10 py-4 rounded-2xl text-lg font-semibold text-white shadow-xl"
            >
              EXPLORE THE MENU
              <ArrowRight className="group-hover:translate-x-1 transition" size={21} />
            </button>
            <button 
              onClick={() => scrollToSection('order')}
              className="btn-secondary flex items-center justify-center gap-3 px-9 py-4 rounded-2xl text-lg font-medium"
            >
              ORDER NOW
            </button>
          </div>

          {/* The Star: 3D Burger */}
          <div className="relative mx-auto w-full max-w-[620px] h-[480px] md:h-[540px] burger-container">
            <div className="absolute inset-0 rounded-[3.5rem] bg-black/60 border border-white/10 shadow-[0_0_80px_rgba(0,0,0,0.6)]" />
            <div className="absolute inset-2 rounded-[3rem] overflow-hidden border border-white/5">
              <Burger3D />
            </div>
            
            {/* Cinematic frame accents */}
            <div className="absolute -inset-1 rounded-[3.75rem] border border-brand-orange/10 pointer-events-none" />
            <div className="absolute -inset-3 rounded-[4rem] border border-brand-yellow/5 pointer-events-none" />
          </div>

          <p className="mt-6 text-xs tracking-[3px] text-white/40 font-mono">DRAG OR MOVE YOUR MOUSE OVER THE BURGER</p>
        </div>

        {/* Scroll indicator */}
        <div 
          onClick={() => scrollToSection('menu')}
          className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center text-white/50 text-xs tracking-[3px] cursor-pointer hover:text-white/80 transition-colors"
        >
          SCROLL TO BEGIN
          <div className="w-px h-8 bg-gradient-to-b from-white/40 to-transparent mt-1.5" />
        </div>
      </section>

      {/* ========== MENU ========== */}
      <section id="menu" className="max-w-7xl mx-auto px-6 pb-20 pt-10">
        <div className="flex items-end justify-between mb-10">
          <div>
            <div className="uppercase tracking-[4px] text-xs text-brand-orange mb-2 font-medium">CURATED SELECTIONS</div>
            <h2 className="section-title text-6xl font-semibold tracking-[-2.5px]">The Menu</h2>
          </div>
          <div className="hidden md:block text-right text-sm text-white/50 max-w-[260px]">
            Every dish crafted with street heat and modern precision.
          </div>
        </div>

        {menuData.map((category, catIndex) => (
          <div key={category.id} className="mb-14 last:mb-0">
            {/* Category Header with Neon Frame */}
            <div className="glass rounded-3xl border border-white/10 px-8 py-6 mb-6 flex items-center justify-between">
              <div>
                <div className="text-brand-orange text-xs tracking-[4px] font-medium mb-px">SECTION {String(catIndex + 1).padStart(2, '0')}</div>
                <h3 className="text-3xl font-semibold tracking-tight">{category.title}</h3>
              </div>
              <div className="text-right text-sm text-white/50 font-mono hidden sm:block">
                {category.items.length} ITEMS
              </div>
            </div>

            {/* Items Grid - 3 columns */}
            <div className="menu-grid">
              {category.items.map((item) => (
                <MenuCard 
                  key={item.id} 
                  item={item} 
                  onAddToCart={addToCart} 
                />
              ))}
            </div>
          </div>
        ))}

        <div className="mt-10 text-center">
          <button 
            onClick={openCart}
            className="inline-flex items-center gap-3 text-sm font-medium tracking-widest px-8 py-3 rounded-2xl border border-brand-orange/40 hover:border-brand-orange text-brand-orange hover:text-white hover:bg-brand-orange/10 transition-all"
          >
            VIEW YOUR CURRENT ORDER ({cartCount}) 
            <ArrowRight size={16} />
          </button>
        </div>
      </section>

      {/* ========== REVIEWS ========== */}
      <section id="reviews" className="bg-[#0F0F13] border-y border-white/10 py-16">
        <div className="max-w-6xl mx-auto px-6">
          <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4 mb-10">
            <div>
              <div className="flex items-center gap-3 mb-3">
                <div className="px-4 py-1 rounded-full bg-white/5 text-xs tracking-widest border border-white/10">GUEST VOICES</div>
                <div className="flex items-center gap-1 text-brand-yellow">
                  <Star size={15} className="fill-current" /> <span className="font-mono text-xs">4.9</span>
                </div>
              </div>
              <h2 className="section-title text-5xl md:text-6xl font-semibold tracking-[-2px]">Real Experiences</h2>
            </div>
            <div className="text-white/60 max-w-xs text-sm md:text-base md:text-right">
              Over 12,400 guests have experienced the cinematic journey.
            </div>
          </div>

          {/* Reviews Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 mb-14">
            <AnimatePresence>
              {reviews.slice(0, 6).map((review, index) => (
                <motion.div
                  key={review.id}
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: Math.min(index * 0.03, 0.2) }}
                  className="review-card glass rounded-3xl p-7 border border-white/10 flex flex-col"
                >
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-brand-orange/80 to-brand-yellow/80 flex items-center justify-center text-brand-black font-bold text-sm tracking-tight">
                      {review.avatar}
                    </div>
                    <div className="flex-1">
                      <div className="font-medium text-lg tracking-tight">{review.name}</div>
                      <div className="text-xs text-white/50 font-mono">{review.date}</div>
                    </div>
                    <StarRating rating={review.rating} readonly size={17} />
                  </div>
                  <p className="text-[15px] leading-relaxed text-white/85 flex-1">“{review.comment}”</p>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>

          {/* Add Review Form */}
          <div className="max-w-2xl mx-auto">
            <div className="glass rounded-3xl p-8 border border-white/10">
              <div className="flex items-center gap-3 mb-6">
                <Users className="text-brand-orange" size={22} />
                <h3 className="font-semibold text-2xl tracking-tight">Share Your Experience</h3>
              </div>

              <form onSubmit={handleReviewSubmit} className="space-y-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs tracking-widest text-white/60 block mb-1.5">YOUR NAME</label>
                    <input
                      type="text"
                      value={newReview.name}
                      onChange={(e) => setNewReview({ ...newReview, name: e.target.value })}
                      placeholder="Alex Rivera"
                      className="input-glass w-full px-5 py-3.5 rounded-2xl text-lg placeholder:text-white/40 focus:outline-none"
                      required
                    />
                  </div>
                  <div>
                    <label className="text-xs tracking-widest text-white/60 block mb-1.5">YOUR RATING</label>
                    <div className="bg-white/5 border border-white/10 rounded-2xl px-5 py-[13px]">
                      <StarRating 
                        rating={newReview.rating} 
                        onRatingChange={(r) => setNewReview({ ...newReview, rating: r })} 
                        size={22} 
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <label className="text-xs tracking-widest text-white/60 block mb-1.5">YOUR REVIEW</label>
                  <textarea
                    value={newReview.comment}
                    onChange={(e) => setNewReview({ ...newReview, comment: e.target.value })}
                    placeholder="The 3D burger and the Elote Burger completely blew me away..."
                    rows={4}
                    className="input-glass w-full px-5 py-4 rounded-2xl resize-y min-h-[108px] placeholder:text-white/40 focus:outline-none text-[15px]"
                    required
                  />
                </div>

                <button 
                  type="submit" 
                  disabled={isSubmittingReview}
                  className="btn-primary w-full py-4 text-base font-semibold rounded-2xl disabled:opacity-70 flex items-center justify-center gap-2"
                >
                  {isSubmittingReview ? "SUBMITTING..." : "SUBMIT MY REVIEW"}
                  <Star size={17} />
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* ========== ORDER / CONTACT ========== */}
      <section id="order" className="max-w-5xl mx-auto px-6 py-20">
        <div className="text-center mb-12">
          <div className="inline-block px-5 py-1 rounded-full bg-white/5 text-xs tracking-[4.5px] border border-white/10 mb-4">EXPERIENCE THE HEAT</div>
          <h2 className="section-title text-6xl font-semibold tracking-[-2.2px] mb-4">Ready to Order?</h2>
          <p className="text-xl text-white/70 max-w-md mx-auto">Fast, premium, and unforgettable. Order for pickup, delivery, or dine-in.</p>
        </div>

        <div className="grid md:grid-cols-5 gap-6">
          {/* Direct Contact CTAs */}
          <div className="md:col-span-3 glass rounded-3xl p-9 border border-white/10">
            <div className="uppercase text-brand-orange text-xs tracking-[3px] mb-3">DIRECT LINE</div>
            <div className="text-5xl font-semibold tracking-tighter mb-1">312.555.0192</div>
            <div className="text-white/50 mb-8">Open daily 11am — 11pm</div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <a 
                href="tel:3125550192" 
                className="btn-primary flex items-center justify-center gap-3 py-5 text-lg font-medium rounded-2xl text-white"
              >
                <Phone size={21} /> CALL NOW
              </a>
              <a 
                href="https://wa.me/13125550192?text=Hi%20Streeters%20Bar_Grill%2C%20I%27d%20like%20to%20place%20an%20order." 
                target="_blank" 
                rel="noopener noreferrer"
                className="btn-secondary flex items-center justify-center gap-3 py-5 text-lg font-medium rounded-2xl"
              >
                <MessageCircle size={21} /> WHATSAPP
              </a>
            </div>
          </div>

          {/* Quick Stats / Trust */}
          <div className="md:col-span-2 glass rounded-3xl p-9 border border-white/10 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 mb-5 text-brand-yellow">
                <Award size={21} /> <span className="font-medium">PREMIUM EXPERIENCE</span>
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between border-b border-white/10 pb-2">
                  <span className="text-white/70">Average wait time</span> 
                  <span className="font-mono text-brand-yellow">8 min</span>
                </div>
                <div className="flex justify-between border-b border-white/10 pb-2">
                  <span className="text-white/70">Orders fulfilled today</span> 
                  <span className="font-mono text-brand-yellow">284</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-white/70">Satisfaction rating</span> 
                  <span className="font-mono text-brand-yellow">4.9/5</span>
                </div>
              </div>
            </div>

            <button 
              onClick={() => scrollToSection('menu')}
              className="mt-8 w-full py-4 border border-brand-orange/50 hover:bg-brand-orange/5 rounded-2xl text-sm font-medium tracking-widest transition flex items-center justify-center gap-2"
            >
              BROWSE FULL MENU <ArrowRight size={17} />
            </button>
          </div>
        </div>

        {/* Strong CTA */}
        <div className="mt-8 text-center">
          <button 
            onClick={openCart}
            className="group inline-flex items-center gap-4 px-11 py-5 bg-white text-brand-black font-semibold text-xl rounded-3xl hover:bg-brand-yellow active:scale-[0.985] transition-all"
          >
            {cartCount > 0 ? `COMPLETE YOUR ORDER (${cartCount} ITEMS)` : "START YOUR ORDER"}
            <ArrowRight className="group-hover:translate-x-1 transition" />
          </button>
          <p className="text-xs text-white/40 mt-4 tracking-widest">CART UPDATES IN REAL-TIME • NO COMMITMENT UNTIL CONFIRMED</p>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-white/10 py-9 text-center text-sm text-white/40">
        <div className="max-w-5xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-y-3 text-xs tracking-widest">
          <div>© STREETERS BAR_GRILL 2026. ALL RIGHTS RESERVED.</div>
          <div className="flex gap-x-6">
            <span>CHICAGO • LOS ANGELES • MIAMI</span>
            <span>DESIGNED FOR THE FUTURE</span>
          </div>
          <div>AMERICAN HEAT. STREET FLAVOR.</div>
        </div>
      </footer>

      {/* Cart Modal */}
      <CartModal 
        isOpen={isCartOpen}
        onClose={closeCart}
        cart={cart}
        onUpdateQuantity={updateCartQuantity}
        onRemoveItem={removeFromCart}
        onCheckout={handleCheckout}
        onWhatsAppOrder={handleWhatsAppOrder}
      />
    </div>
  );
}
