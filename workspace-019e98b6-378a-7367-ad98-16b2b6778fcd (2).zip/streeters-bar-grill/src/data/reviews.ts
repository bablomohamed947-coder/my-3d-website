export interface Review {
  id: number;
  name: string;
  rating: number;
  comment: string;
  date: string;
  avatar: string;
}

export const initialReviews: Review[] = [
  {
    id: 1,
    name: "Marcus Chen",
    rating: 5,
    comment: "The 3D burger experience is absolutely mind-blowing. Tastes even better than it looks. Best American food in the city!",
    date: "2 days ago",
    avatar: "MC"
  },
  {
    id: 2,
    name: "Sofia Ramirez",
    rating: 5,
    comment: "Incredible atmosphere and the Elote Burger is life-changing. The neon vibe and cinematic feel make it unforgettable.",
    date: "1 week ago",
    avatar: "SR"
  },
  {
    id: 3,
    name: "Jamal Washington",
    rating: 4,
    comment: "Steak Bites and the Manager Special burger are next level. Service was fast and the 3D model is so cool to watch.",
    date: "2 weeks ago",
    avatar: "JW"
  },
  {
    id: 4,
    name: "Elena Petrova",
    rating: 5,
    comment: "Took my kids here — they loved the Kids Menu and I was blown away by the Flatbreads. Premium experience all around.",
    date: "3 weeks ago",
    avatar: "EP"
  },
  {
    id: 5,
    name: "David Kim",
    rating: 5,
    comment: "The futuristic design and 3D burger are insane. Food is authentic street-style with a premium twist. Highly recommend!",
    date: "1 month ago",
    avatar: "DK"
  }
];
