export interface MenuItem {
  id: number;
  name: string;
  price: number;
  desc: string;
}

export interface MenuCategory {
  id: number;
  title: string;
  items: MenuItem[];
}

export const menuData: MenuCategory[] = [
  {
    id: 1,
    title: "Appetizers",
    items: [
      { id: 101, name: "Steak Bites", price: 17, desc: "Juicy sirloin cubes seared with garlic herb butter and chimichurri." },
      { id: 102, name: "Corn Ribs", price: 11, desc: "Crispy corn ribs tossed in chili lime seasoning and cotija cheese." },
      { id: 103, name: "Duck Bacon Wontons", price: 13, desc: "Crispy wontons filled with duck confit, smoky bacon and sweet chili." },
      { id: 104, name: "Creamery Curds", price: 12, desc: "Fresh Wisconsin cheese curds fried golden, served with house ranch." },
      { id: 105, name: "Streeters Spuds", price: 7, desc: "Crispy potato wedges with truffle salt, parmesan and garlic aioli." },
      { id: 106, name: "Fried Pickles 'N' Peppers", price: 11, desc: "Tangy pickles and spicy peppers in a light panko batter." },
      { id: 107, name: "Jumbo Wings", price: 12, desc: "Crispy jumbo chicken wings tossed in your choice of signature sauces." },
      { id: 108, name: "Elote Dip", price: 10, desc: "Creamy street corn dip with roasted corn, cotija and tortilla chips." },
      { id: 109, name: "Cheesy Focaccia", price: 12, desc: "Warm herb focaccia loaded with melted mozzarella, parmesan and garlic." },
    ]
  },
  {
    id: 2,
    title: "Bowls & Greens",
    items: [
      { id: 201, name: "Big Bite Bowl", price: 17, desc: "Grilled steak, quinoa, avocado, black beans, corn and chipotle crema." },
      { id: 202, name: "Caesar", price: 11, desc: "Crisp romaine, shaved parmesan, house croutons and classic Caesar dressing." },
      { id: 203, name: "BLT Bowl", price: 15, desc: "Bacon, grilled chicken, cherry tomatoes, avocado over mixed greens." },
      { id: 204, name: "Side Caesar", price: 6, desc: "Classic small Caesar salad with parmesan and croutons." },
      { id: 205, name: "Berry Crunch Salad", price: 14, desc: "Mixed greens, fresh berries, candied pecans, feta and aged balsamic." },
      { id: 206, name: "Side Salad", price: 6, desc: "Fresh mixed greens with cherry tomatoes and your choice of dressing." },
    ]
  },
  {
    id: 3,
    title: "Sandwiches",
    items: [
      { id: 301, name: "Bruschetta Hammy", price: 15, desc: "Grilled ham, fresh tomato bruschetta, mozzarella on toasted ciabatta." },
      { id: 302, name: "Porky Pig", price: 15, desc: "Slow-cooked pulled pork, creamy coleslaw and pickles on brioche bun." },
      { id: 303, name: "The Shift Meal", price: 16, desc: "Grilled chicken breast, avocado, bacon, swiss cheese on sourdough." },
      { id: 304, name: "Streeters Stacker", price: 18, desc: "Double stack of turkey, ham, bacon, swiss and our special sauce." },
      { id: 305, name: "The Toasty Chicken", price: 15, desc: "Crispy chicken, pickles, slaw and spicy mayo on toasted brioche." },
    ]
  },
  {
    id: 4,
    title: "Burgers",
    items: [
      { id: 401, name: "The Fun-Gi", price: 15, desc: "Beef patty, sautéed mushrooms, swiss cheese and truffle aioli." },
      { id: 402, name: "Boring Burger", price: 12, desc: "Classic beef, lettuce, tomato, onion, pickles and special sauce." },
      { id: 403, name: "Elote Burger", price: 15, desc: "Beef patty, street corn relish, cotija cheese, lime crema and jalapeños." },
      { id: 404, name: "Manager Special", price: 16, desc: "Double beef patties, cheddar, bacon, onion rings and tangy BBQ." },
    ]
  },
  {
    id: 5,
    title: "Flatbreads",
    items: [
      { id: 501, name: "The Campout", price: 14, desc: "Pepperoni, mozzarella, house marinara and fresh basil leaves." },
      { id: 502, name: "Guajillo Steak Flatbread", price: 16, desc: "Grilled steak, guajillo chili sauce, caramelized onions and queso." },
      { id: 503, name: "Bruschetta", price: 14, desc: "Heirloom tomatoes, fresh basil, balsamic glaze and buffalo mozzarella." },
      { id: 504, name: "Philly Flatbread", price: 15, desc: "Shaved ribeye, sautéed peppers, onions and melted provolone." },
      { id: 505, name: "Thats A Spicy Pickle", price: 18, desc: "Spicy fried chicken, house pickles, ranch and hot honey drizzle." },
      { id: 506, name: "The Michelangelo", price: 17, desc: "Italian sausage, roasted red peppers, olives and fresh mozzarella." },
    ]
  },
  {
    id: 6,
    title: "Soup & Salads",
    items: [
      { id: 601, name: "White Chicken Chili", price: 5, desc: "Hearty white chicken chili with white beans, cumin and fresh cilantro." },
      { id: 602, name: "Soup Du Jour", price: 5, desc: "Chef's daily selection of house-made soup. Ask your server." },
      { id: 603, name: "The Fainting Goat", price: 12, desc: "Goat cheese, roasted beets, candied walnuts over arugula with honey vinaigrette." },
      { id: 604, name: "Rodeo Salad", price: 15, desc: "Grilled chicken, roasted corn, black beans, avocado and crispy tortilla strips." },
      { id: 605, name: "Side Salad", price: 5, desc: "Simple mixed greens with tomatoes and choice of dressing." },
    ]
  },
  {
    id: 7,
    title: "Kids Menu",
    items: [
      { id: 701, name: "Grilled Cheese", price: 7, desc: "Classic American cheese melted between slices of sourdough bread." },
      { id: 702, name: "Mac N Cheese", price: 7, desc: "Creamy elbow macaroni baked with sharp cheddar cheese sauce." },
      { id: 703, name: "Hamburger", price: 7, desc: "All-beef patty on a soft bun with ketchup on the side." },
      { id: 704, name: "Cheeseburger", price: 7, desc: "All-beef patty with melted American cheese on a soft bun." },
    ]
  },
  {
    id: 8,
    title: "Tacos",
    items: [
      { id: 801, name: "Carnitas", price: 5, desc: "Slow-cooked pork carnitas, diced onion, cilantro and salsa verde." },
      { id: 802, name: "Chicken Asada", price: 5, desc: "Grilled marinated chicken, pico de gallo, avocado and lime." },
      { id: 803, name: "Beef", price: 4, desc: "Seasoned ground beef, shredded lettuce, cheddar and fresh pico." },
    ]
  },
  {
    id: 9,
    title: "Others",
    items: [
      { id: 901, name: "Braised Beef", price: 14, desc: "Tender braised beef shoulder with red wine reduction and herbs." },
      { id: 902, name: "Pulled Pork", price: 13, desc: "Slow-smoked pulled pork shoulder with house BBQ sauce." },
      { id: 903, name: "Chicken", price: 12, desc: "Grilled or fried chicken breast with choice of sauce." },
      { id: 904, name: "Seafood", price: 16, desc: "Grilled shrimp and calamari with lemon garlic butter." },
      { id: 905, name: "Coca-Cola", price: 3, desc: "Classic Coca-Cola or choice of fountain soda." },
    ]
  }
];
