import { useState } from 'react';
import type { MouseEvent } from 'react';
import { motion } from 'framer-motion';
import { Plus } from 'lucide-react';
import type { MenuItem } from '../data/menu';

interface MenuCardProps {
  item: MenuItem;
  onAddToCart: (item: MenuItem) => void;
}

const getFoodEmoji = (name: string): string => {
  const lower = name.toLowerCase();
  if (lower.includes('steak') || lower.includes('beef')) return '🥩';
  if (lower.includes('burger')) return '🍔';
  if (lower.includes('chicken') || lower.includes('wings')) return '🍗';
  if (lower.includes('corn') || lower.includes('elote')) return '🌽';
  if (lower.includes('salad') || lower.includes('greens') || lower.includes('caesar')) return '🥗';
  if (lower.includes('taco')) return '🌮';
  if (lower.includes('flatbread') || lower.includes('pizza')) return '🍕';
  if (lower.includes('soup') || lower.includes('chili')) return '🍲';
  if (lower.includes('cheese') || lower.includes('mac')) return '🧀';
  if (lower.includes('bacon') || lower.includes('pork')) return '🥓';
  if (lower.includes('pickl')) return '🥒';
  if (lower.includes('cola') || lower.includes('soda')) return '🥤';
  if (lower.includes('bowl')) return '🍲';
  if (lower.includes('sandwich') || lower.includes('ham')) return '🥪';
  return '🍽️';
};

const getPlaceholderColor = (name: string): string => {
  const lower = name.toLowerCase();
  if (lower.includes('burger') || lower.includes('beef') || lower.includes('steak')) return 'from-[#3D2314] to-[#5C4033]';
  if (lower.includes('chicken') || lower.includes('wings')) return 'from-[#8B5A2B] to-[#A0522D]';
  if (lower.includes('salad') || lower.includes('greens')) return 'from-[#2E5A2E] to-[#3A6B3A]';
  if (lower.includes('cheese') || lower.includes('mac')) return 'from-[#D4A017] to-[#B8860B]';
  if (lower.includes('taco') || lower.includes('corn')) return 'from-[#E67E22] to-[#D35400]';
  if (lower.includes('soup')) return 'from-[#5D4E37] to-[#6B5B47]';
  return 'from-[#2A2A30] to-[#1F1F24]';
};

export default function MenuCard({ item, onAddToCart }: MenuCardProps) {
  const [isHovered, setIsHovered] = useState(false);

  const handleAdd = (e: MouseEvent<HTMLButtonElement>) => {
    e.stopPropagation();
    onAddToCart(item);
  };

  return (
    <motion.div
      whileHover={{ 
        y: -6, 
        transition: { type: "spring", stiffness: 300, damping: 20 } 
      }}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      className="menu-card group relative bg-brand-black border border-white/10 rounded-2xl overflow-hidden flex flex-col h-full"
    >
      {/* Food Visual Placeholder with 3D-ish hover float */}
      <div 
        className={`food-placeholder h-44 relative flex items-center justify-center text-7xl transition-all duration-500 ${isHovered ? 'scale-[1.08]' : ''}`}
        style={{
          background: `linear-gradient(145deg, #1F1F24, #151518)`,
        }}
      >
        <div 
          className={`transition-transform duration-500 ${isHovered ? 'rotate-[-6deg] scale-110' : ''}`}
        >
          <span className="drop-shadow-[0_4px_12px_rgba(0,0,0,0.6)] select-none">
            {getFoodEmoji(item.name)}
          </span>
        </div>

        {/* Neon accent glow on hover */}
        <div className={`absolute inset-0 bg-gradient-to-br ${getPlaceholderColor(item.name)} opacity-40 group-hover:opacity-60 transition-opacity`} />
        
        {/* Price badge floating */}
        <div className="absolute top-3 right-3 bg-brand-black/90 text-brand-yellow font-mono text-sm px-3 py-0.5 rounded-full border border-brand-yellow/40 backdrop-blur-sm">
          ${item.price}
        </div>

        {/* Subtle 3D depth lines */}
        <div className="absolute inset-0 bg-[linear-gradient(transparent_40%,rgba(255,255,255,0.03)_50%,transparent_60%)] pointer-events-none" />
      </div>

      {/* Content */}
      <div className="p-5 flex flex-col flex-1 bg-[#111114]">
        <div className="flex-1">
          <h4 className="font-semibold text-lg tracking-[-0.3px] text-white mb-1.5 group-hover:text-brand-orange transition-colors">
            {item.name}
          </h4>
          <p className="text-sm text-brand-light/90 leading-snug line-clamp-3">
            {item.desc}
          </p>
        </div>

        {/* Add to Order Button */}
        <button
          onClick={handleAdd}
          className="mt-4 w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-white/5 hover:bg-brand-orange hover:text-white border border-white/10 hover:border-brand-orange/60 text-sm font-medium transition-all active:scale-[0.985] group/btn"
        >
          <Plus size={16} className="transition-transform group-hover/btn:rotate-90" />
          <span>ADD TO ORDER</span>
        </button>
      </div>

      {/* Neon border accent on hover */}
      <div className="absolute inset-0 rounded-2xl border border-brand-orange/0 group-hover:border-brand-orange/40 pointer-events-none transition-colors" />
    </motion.div>
  );
}
