import React, { useRef, useState } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';

interface BurgerModelProps {
  mouseX: number;
  mouseY: number;
}

function BurgerModel({ mouseX, mouseY }: BurgerModelProps) {
  const groupRef = useRef<THREE.Group>(null!);
  useThree(); // used for context if needed, clock accessed via state in useFrame

  // Auto rotate + mouse parallax
  useFrame((state) => {
    if (groupRef.current) {
      const time = state.clock.elapsedTime;
      
      // Continuous slow rotation
      const autoRotate = time * 0.12;
      
      // Mouse parallax influence (subtle)
      const targetY = autoRotate + mouseX * 0.8;
      const targetX = mouseY * 0.45;
      
      // Smooth interpolation
      groupRef.current.rotation.y = THREE.MathUtils.lerp(
        groupRef.current.rotation.y, 
        targetY, 
        0.04
      );
      groupRef.current.rotation.x = THREE.MathUtils.lerp(
        groupRef.current.rotation.x, 
        targetX, 
        0.06
      );
      
      // Gentle floating bob
      groupRef.current.position.y = Math.sin(time * 1.1) * 0.08;
      
      // Very subtle scale pulse for cinematic feel
      const pulse = 1 + Math.sin(time * 0.7) * 0.008;
      groupRef.current.scale.setScalar(pulse);
    }
  });

  // Materials
  const bunMaterial = new THREE.MeshPhongMaterial({ 
    color: '#E8C48A', 
    shininess: 35, 
    specular: '#FFFFFF',
    flatShading: false 
  });
  
  const pattyMaterial = new THREE.MeshPhongMaterial({ 
    color: '#3D2314', 
    shininess: 15,
    specular: '#222222'
  });
  
  const cheeseMaterial = new THREE.MeshPhongMaterial({ 
    color: '#F4C430', 
    shininess: 60,
    specular: '#FFF8DC',
    emissive: '#3D2A00',
    emissiveIntensity: 0.1
  });
  
  const lettuceMaterial = new THREE.MeshPhongMaterial({ 
    color: '#2E7D32', 
    shininess: 8 
  });
  
  const tomatoMaterial = new THREE.MeshPhongMaterial({ 
    color: '#C62828', 
    shininess: 25 
  });
  
  const sesameMaterial = new THREE.MeshPhongMaterial({ 
    color: '#F5DEB3', 
    shininess: 10 
  });

  // Create sesame seeds positions on top bun
  const sesamePositions: [number, number, number][] = [
    [0.6, 1.65, 0.3], [-0.5, 1.7, 0.5], [0.2, 1.68, -0.6],
    [-0.7, 1.72, -0.2], [0.8, 1.66, -0.4], [-0.3, 1.69, 0.8],
    [0.1, 1.71, 0.9], [-0.9, 1.65, 0.1]
  ];

  return (
    <group ref={groupRef}>
      {/* Bottom Bun */}
      <mesh position={[0, -1.35, 0]} material={bunMaterial} castShadow receiveShadow>
        <cylinderGeometry args={[1.45, 1.55, 0.65, 48]} />
      </mesh>

      {/* Patty */}
      <mesh position={[0, -0.65, 0]} material={pattyMaterial} castShadow receiveShadow>
        <cylinderGeometry args={[1.32, 1.38, 0.42, 48]} />
      </mesh>

      {/* Cheese Layer - slightly melted look with bigger size */}
      <mesh position={[0, -0.35, 0]} material={cheeseMaterial} castShadow>
        <boxGeometry args={[2.55, 0.18, 2.55]} />
      </mesh>

      {/* Lettuce - multiple layered wavy pieces */}
      {[0, 1, 2, 3].map((i) => (
        <group key={i} position={[0, -0.15 + i * 0.08, 0]} rotation={[0, i * 0.8, 0]}>
          <mesh material={lettuceMaterial} castShadow>
            <torusGeometry args={[1.25 + i * 0.08, 0.18, 12, 32, Math.PI * 1.6]} />
          </mesh>
        </group>
      ))}

      {/* Tomato slices */}
      {[0, 1, 2].map((i) => (
        <mesh 
          key={i} 
          position={[i === 1 ? 0.35 : i === 2 ? -0.4 : 0, 0.05 + i * 0.12, i === 0 ? 0.3 : i === 1 ? -0.25 : 0.15]} 
          material={tomatoMaterial} 
          castShadow
        >
          <cylinderGeometry args={[0.75, 0.75, 0.12, 32]} />
        </mesh>
      ))}

      {/* Top Bun */}
      <mesh position={[0, 0.85, 0]} material={bunMaterial} castShadow receiveShadow>
        <cylinderGeometry args={[1.42, 1.5, 0.75, 48]} />
      </mesh>

      {/* Sesame Seeds on top bun */}
      {sesamePositions.map((pos, index) => (
        <mesh 
          key={index} 
          position={pos} 
          material={sesameMaterial} 
          castShadow
        >
          <sphereGeometry args={[0.09]} />
        </mesh>
      ))}

      {/* Extra detail: Bacon strips (thin angled planes) */}
      <mesh position={[-0.6, 0.1, 0.7]} rotation={[0.6, 0.3, -0.4]} material={new THREE.MeshPhongMaterial({ color: '#8B4513', shininess: 12 })}>
        <boxGeometry args={[1.8, 0.08, 0.45]} />
      </mesh>
      <mesh position={[0.5, 0.15, -0.6]} rotation={[-0.5, -0.2, 0.5]} material={new THREE.MeshPhongMaterial({ color: '#8B4513', shininess: 12 })}>
        <boxGeometry args={[1.6, 0.08, 0.4]} />
      </mesh>

      {/* Pickle slices */}
      <mesh position={[-0.85, 0.22, 0.4]} rotation={[0.2, 0, 0]} material={new THREE.MeshPhongMaterial({ color: '#4A7C59', shininess: 30 })}>
        <cylinderGeometry args={[0.28, 0.28, 0.1, 24]} />
      </mesh>
      <mesh position={[0.7, 0.18, -0.55]} rotation={[-0.15, 0.8, 0]} material={new THREE.MeshPhongMaterial({ color: '#4A7C59', shininess: 30 })}>
        <cylinderGeometry args={[0.26, 0.26, 0.1, 24]} />
      </mesh>

      {/* Subtle highlight ring around burger for cinematic */}
      <mesh position={[0, 0, 0]} rotation={[Math.PI / 2, 0, 0]}>
        <ringGeometry args={[1.65, 1.72, 64]} />
        <meshBasicMaterial color="#FF6A00" transparent opacity={0.08} side={THREE.DoubleSide} />
      </mesh>
    </group>
  );
}

interface Burger3DProps {
  className?: string;
}

export default function Burger3D({ className = '' }: Burger3DProps) {
  const [mouse, setMouse] = useState({ x: 0, y: 0 });
  const containerRef = React.useRef<HTMLDivElement>(null);

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!containerRef.current) return;
    
    const rect = containerRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width - 0.5) * 2; // -1 to 1
    const y = ((e.clientY - rect.top) / rect.height - 0.5) * 2;
    
    // Clamp and invert Y for natural feel
    setMouse({ 
      x: Math.max(-1, Math.min(1, x)), 
      y: Math.max(-0.6, Math.min(0.6, -y)) 
    });
  };

  const handleMouseLeave = () => {
    // Gently return to center
    setMouse({ x: 0, y: 0 });
  };

  return (
    <div 
      ref={containerRef}
      className={`relative w-full h-full cursor-grab active:cursor-grabbing ${className}`}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
    >
      <Canvas
        camera={{ position: [0, 0.8, 5.5], fov: 42 }}
        style={{ background: 'transparent' }}
        gl={{ 
          alpha: true, 
          antialias: true, 
          preserveDrawingBuffer: true,
          toneMapping: THREE.ACESFilmicToneMapping,
          toneMappingExposure: 1.1
        }}
      >
        {/* Cinematic Lighting */}
        <ambientLight intensity={0.35} color="#F5F5F5" />
        
        {/* Main key light - warm cinematic */}
        <directionalLight 
          position={[6, 12, 4]} 
          intensity={1.1} 
          color="#FFF8E7"
          castShadow
          shadow-mapSize={[1024, 1024]}
        />
        
        {/* Neon orange rim / fill light */}
        <pointLight 
          position={[-7, -1, 6]} 
          intensity={1.6} 
          color="#FF6A00" 
        />
        
        {/* Neon yellow accent light */}
        <pointLight 
          position={[8, 4, -5]} 
          intensity={0.9} 
          color="#FFC300" 
        />
        
        {/* Top spot for drama */}
        <spotLight 
          position={[0, 14, -2]} 
          angle={0.35} 
          penumbra={0.6} 
          intensity={0.7} 
          color="#FFAA55"
          castShadow
        />

        {/* The Burger */}
        <BurgerModel mouseX={mouse.x} mouseY={mouse.y} />

        {/* Subtle ground plane for grounding and reflections */}
        <mesh position={[0, -2.1, 0]} rotation={[-Math.PI * 0.5, 0, 0]} receiveShadow>
          <circleGeometry args={[3.8]} />
          <meshPhongMaterial 
            color="#0B0B0F" 
            shininess={80} 
            specular="#222"
            transparent 
            opacity={0.6}
          />
        </mesh>

        {/* Very subtle fog for depth */}
        {/* <fog attach="fog" args={['#0B0B0F', 8, 18]} /> */}
      </Canvas>

      {/* Subtle vignette overlay for cinematic look */}
      <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(circle_at_center,transparent_40%,rgba(11,11,15,0.65)_75%)]" />
      
      {/* Hover instruction */}
      <div className="absolute bottom-4 right-4 text-[10px] text-brand-yellow/60 font-mono tracking-[2px] pointer-events-none select-none">
        MOVE MOUSE TO INTERACT
      </div>
    </div>
  );
}
