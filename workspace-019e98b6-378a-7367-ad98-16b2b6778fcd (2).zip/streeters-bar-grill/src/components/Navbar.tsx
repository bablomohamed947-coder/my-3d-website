import React from 'react';
import { Menu, X, ShoppingCart } from 'lucide-react';

interface NavbarProps {
  activeSection: string;
  onNavClick: (section: string) => void;
  cartCount: number;
  onCartClick: () => void;
}

export default function Navbar({ activeSection, onNavClick, cartCount, onCartClick }: NavbarProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);

  const navLinks = [
    { label: 'Home', id: 'home' },
    { label: 'Menu', id: 'menu' },
    { label: 'Reviews', id: 'reviews' },
    { label: 'Order', id: 'order' },
  ];

  const handleNav = (id: string) => {
    onNavClick(id);
    setIsMobileMenuOpen(false);
  };

  return (
    <nav className="navbar fixed top-0 left-0 right-0 z-[100] bg-brand-black/90 backdrop-blur-xl border-b border-white/10">
      <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
        {/* Logo */}
        <div 
          onClick={() => handleNav('home')}
          className="flex items-center gap-3 cursor-pointer group"
        >
          <div className="w-9 h-9 rounded-full bg-gradient-to-br from-brand-orange to-brand-yellow flex items-center justify-center">
            <span className="text-brand-black font-bold text-xl tracking-[-1.5px]">S</span>
          </div>
          <div>
            <div className="font-semibold text-2xl tracking-[-1.5px] text-white group-hover:text-brand-orange transition-colors">
              STREETERS
            </div>
            <div className="text-[9px] text-brand-yellow/70 -mt-1.5 tracking-[3.5px] font-mono">BAR_GRILL</div>
          </div>
        </div>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center gap-10 text-sm font-medium tracking-wide">
          {navLinks.map((link) => (
            <button
              key={link.id}
              onClick={() => handleNav(link.id)}
              className={`relative pb-1 transition-colors hover:text-brand-orange ${
                activeSection === link.id 
                  ? 'text-white after:absolute after:bottom-0 after:left-0 after:h-[1px] after:w-full after:bg-brand-orange' 
                  : 'text-white/70'
              }`}
            >
              {link.label}
            </button>
          ))}
        </div>

        {/* Right side actions */}
        <div className="flex items-center gap-3">
          {/* Cart Button */}
          <button
            onClick={onCartClick}
            className="relative flex items-center gap-2 px-4 py-2 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 hover:border-brand-orange/30 transition-all active:scale-[0.985]"
          >
            <ShoppingCart size={18} />
            <span className="hidden sm:inline text-sm font-medium">ORDER</span>
            {cartCount > 0 && (
              <div className="absolute -top-1 -right-1 min-w-[19px] h-[19px] px-1.5 rounded-full bg-brand-orange text-[10px] font-mono flex items-center justify-center text-black font-bold">
                {cartCount}
              </div>
            )}
          </button>

          {/* Mobile Menu Toggle */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="md:hidden p-2.5 rounded-2xl bg-white/5 border border-white/10"
            aria-label="Toggle menu"
          >
            {isMobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden border-t border-white/10 bg-brand-black/95 px-6 py-6 flex flex-col gap-1 text-lg">
          {navLinks.map((link) => (
            <button
              key={link.id}
              onClick={() => handleNav(link.id)}
              className={`py-3 text-left transition-colors ${activeSection === link.id ? 'text-brand-orange' : 'text-white/80'}`}
            >
              {link.label}
            </button>
          ))}
          <div className="h-px bg-white/10 my-2" />
          <button onClick={onCartClick} className="py-3 text-left flex items-center gap-3 text-white/80">
            <ShoppingCart size={19} /> View Order ({cartCount})
          </button>
        </div>
      )}
    </nav>
  );
}
