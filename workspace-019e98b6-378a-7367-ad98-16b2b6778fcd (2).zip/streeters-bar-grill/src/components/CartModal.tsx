import { motion, AnimatePresence } from 'framer-motion';
import { X, Phone, MessageCircle, Trash2, Plus, Minus } from 'lucide-react';
import type { MenuItem } from '../data/menu';

export interface CartItem extends MenuItem {
  quantity: number;
}

interface CartModalProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  onUpdateQuantity: (id: number, newQuantity: number) => void;
  onRemoveItem: (id: number) => void;
  onCheckout: () => void;
  onWhatsAppOrder: () => void;
}

export default function CartModal({
  isOpen,
  onClose,
  cart,
  onUpdateQuantity,
  onRemoveItem,
  onCheckout,
  onWhatsAppOrder,
}: CartModalProps) {
  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const itemCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  const generateWhatsAppText = () => {
    let text = "Hi Streeters Bar_Grill! I'd like to place an order:\n\n";
    cart.forEach(item => {
      text += `• ${item.quantity}x ${item.name} - $${(item.price * item.quantity).toFixed(2)}\n`;
    });
    text += `\nTotal: $${total.toFixed(2)}\n\nPlease confirm availability. Thank you!`;
    return encodeURIComponent(text);
  };

  const handleWhatsApp = () => {
    const text = generateWhatsAppText();
    const phone = "13125550192"; // Fake number for demo
    window.open(`https://wa.me/${phone}?text=${text}`, '_blank');
    onWhatsAppOrder();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <motion.div
            initial={{ opacity: 0, scale: 0.96, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 20 }}
            transition={{ type: "spring", stiffness: 300, damping: 26 }}
            className="glass w-full max-w-lg rounded-3xl border border-white/10 overflow-hidden shadow-2xl"
          >
            {/* Header */}
            <div className="flex items-center justify-between px-6 py-5 border-b border-white/10 bg-black/40">
              <div>
                <h3 className="text-2xl font-semibold tracking-tight">Your Order</h3>
                <p className="text-xs text-white/50 font-mono mt-0.5">{itemCount} ITEMS • STREETERS</p>
              </div>
              <button 
                onClick={onClose} 
                className="p-2 rounded-full hover:bg-white/10 transition-colors"
                aria-label="Close cart"
              >
                <X size={22} />
              </button>
            </div>

            {/* Cart Items */}
            <div className="max-h-[420px] overflow-y-auto px-6 py-4 space-y-3 bg-[#0F0F13]">
              {cart.length === 0 ? (
                <div className="text-center py-12 text-white/50">
                  <p className="text-lg">Your cart is empty</p>
                  <p className="text-sm mt-1">Add items from the menu</p>
                </div>
              ) : (
                cart.map((item) => (
                  <div key={item.id} className="flex items-center gap-4 bg-brand-black/60 rounded-2xl p-4 border border-white/5">
                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-white truncate">{item.name}</div>
                      <div className="text-sm text-brand-orange font-mono">${item.price} × {item.quantity}</div>
                    </div>

                    <div className="flex items-center gap-2">
                      {/* Quantity controls */}
                      <div className="flex items-center bg-white/5 rounded-xl border border-white/10">
                        <button 
                          onClick={() => onUpdateQuantity(item.id, Math.max(1, item.quantity - 1))}
                          className="p-2 hover:bg-white/10 rounded-l-xl transition-colors active:bg-white/5"
                        >
                          <Minus size={15} />
                        </button>
                        <div className="px-3 font-mono text-sm tabular-nums w-7 text-center">{item.quantity}</div>
                        <button 
                          onClick={() => onUpdateQuantity(item.id, item.quantity + 1)}
                          className="p-2 hover:bg-white/10 rounded-r-xl transition-colors active:bg-white/5"
                        >
                          <Plus size={15} />
                        </button>
                      </div>

                      <div className="font-mono text-sm w-14 text-right text-brand-yellow">
                        ${(item.price * item.quantity).toFixed(2)}
                      </div>

                      <button 
                        onClick={() => onRemoveItem(item.id)}
                        className="p-2 text-white/40 hover:text-red-400 hover:bg-white/5 rounded-xl transition-colors"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Footer */}
            {cart.length > 0 && (
              <div className="p-6 bg-black/60 border-t border-white/10 space-y-4">
                <div className="flex justify-between items-baseline px-1">
                  <span className="text-white/70 text-sm tracking-widest">TOTAL</span>
                  <span className="text-3xl font-semibold tabular-nums text-white">${total.toFixed(2)}</span>
                </div>

                <div className="grid grid-cols-1 gap-3 pt-1">
                  <button
                    onClick={handleWhatsApp}
                    className="btn-secondary w-full flex items-center justify-center gap-3 py-3.5 text-base font-medium rounded-2xl"
                  >
                    <MessageCircle size={19} />
                    ORDER VIA WHATSAPP
                  </button>

                  <button
                    onClick={onCheckout}
                    className="btn-primary w-full flex items-center justify-center gap-3 py-3.5 text-base font-semibold rounded-2xl text-white"
                  >
                    <Phone size={19} />
                    CONFIRM ORDER &amp; CALL US
                  </button>

                  <p className="text-center text-[11px] text-white/40 pt-1">
                    Our team will confirm your order within minutes
                  </p>
                </div>
              </div>
            )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
