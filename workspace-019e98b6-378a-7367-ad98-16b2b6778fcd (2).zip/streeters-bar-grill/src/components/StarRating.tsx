import React from 'react';
import { Star } from 'lucide-react';

interface StarRatingProps {
  rating: number;
  onRatingChange?: (rating: number) => void;
  readonly?: boolean;
  size?: number;
}

export default function StarRating({ 
  rating, 
  onRatingChange, 
  readonly = false, 
  size = 20 
}: StarRatingProps) {
  const [hoverRating, setHoverRating] = React.useState(0);

  const handleClick = (value: number) => {
    if (!readonly && onRatingChange) {
      onRatingChange(value);
    }
  };

  const handleMouseEnter = (value: number) => {
    if (!readonly) setHoverRating(value);
  };

  const handleMouseLeave = () => {
    if (!readonly) setHoverRating(0);
  };

  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((star) => {
        const isFilled = (hoverRating || rating) >= star;
        return (
          <button
            key={star}
            type="button"
            onClick={() => handleClick(star)}
            onMouseEnter={() => handleMouseEnter(star)}
            onMouseLeave={handleMouseLeave}
            disabled={readonly}
            className={`star p-0.5 transition-all ${!readonly ? 'cursor-pointer' : 'cursor-default'}`}
            aria-label={`${star} star`}
          >
            <Star 
              size={size} 
              className={`
                transition-all duration-150
                ${isFilled 
                  ? 'fill-brand-yellow text-brand-yellow drop-shadow-[0_0_3px_rgba(255,195,0,0.6)]' 
                  : 'text-white/30'
                }
                ${!readonly && hoverRating >= star ? 'scale-110' : ''}
              `}
            />
          </button>
        );
      })}
    </div>
  );
}
