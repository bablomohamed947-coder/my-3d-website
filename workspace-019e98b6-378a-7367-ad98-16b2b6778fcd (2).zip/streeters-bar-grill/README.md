# Streeters Bar_Grill

**A cinematic, futuristic American Fast Food website experience.**

Premium dark neon glassmorphism design featuring an interactive 3D burger built with Three.js, smooth animations via Framer Motion, fully interactive menu with cart system, customer reviews with live submission, and direct order CTAs.

## Features

- **Hero Section**: Massive interactive 3D burger (Three.js + React Three Fiber)
  - Continuous auto-rotation
  - Mouse parallax / tilt interaction
  - Cinematic lighting (spot, point neon lights, ambient)
  - Floating animation + subtle pulse
- **Neon Particle Background**: Custom canvas-based glowing connected particles (orange + yellow neon)
- **Full Menu**: 9 categories, 47+ items with short descriptions, emoji + gradient placeholders, "Add to Order" with hover float + tilt effects
- **Interactive Cart**: Add items, adjust quantities, remove, totals. Modal with WhatsApp + simulated checkout
- **Reviews Wall**: Preloaded reviews + fully functional "Add Your Review" form (stars, name, comment) with live updates + localStorage persistence
- **Order/Contact**: Direct phone call button, WhatsApp deep link (pre-filled), strong CTAs
- **Premium UI/UX**:
  - Glassmorphism cards
  - Neon glow effects & borders
  - Smooth scroll navigation with active section
  - Scroll progress bar
  - Cinematic page feel with Framer Motion
  - Responsive (mobile-first)
  - Sonner toasts for delightful feedback
- **Tech Stack**:
  - React 19 + TypeScript
  - Vite
  - Tailwind CSS 3
  - Three.js + @react-three/fiber + @react-three/drei
  - Framer Motion
  - Lucide icons
  - Sonner (toasts)
  - React Router (installed but not heavily used for SPA scroll experience)

## Project Structure

```
/streeters-bar-grill
├── public/
├── src/
│   ├── components/
│   │   ├── Burger3D.tsx          # The star: fully interactive 3D burger
│   │   ├── ParticleBackground.tsx # Neon floating particles
│   │   ├── Navbar.tsx
│   │   ├── MenuCard.tsx
│   │   ├── StarRating.tsx
│   │   └── CartModal.tsx
│   ├── data/
│   │   ├── menu.ts               # All menu data + types
│   │   └── reviews.ts            # Initial reviews
│   ├── App.tsx                   # Main cinematic SPA
│   ├── main.tsx
│   └── index.css                 # Full custom premium theme
├── index.html
├── package.json
└── README.md
```

## Getting Started

```bash
cd streeters-bar-grill

# Install (already done in this workspace)
npm install

# Run development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

Open http://localhost:5173 in your browser.

The site is fully self-contained and runs 100% client-side. No backend required.

## Customization Notes

- **Logo**: Pure CSS/SVG based. Easy to replace with real image/SVG in Navbar and Hero.
- **3D Burger**: Fully procedural in code (no external models). Easy to tweak geometries, materials, lighting, or add more ingredients.
- **Menu Items**: Edit `src/data/menu.ts`
- **Initial Reviews**: Edit `src/data/reviews.ts`
- **Colors**: Defined in `tailwind.config.js` and `src/index.css` (brand-black, brand-orange, brand-yellow)
- **Cart persistence**: Uses localStorage
- **WhatsApp number**: Hardcoded in CartModal (312.555.0192) — replace with real number

## Design Philosophy

Built from scratch as an original cinematic experience — not a generic restaurant template. Heavy focus on:

- Immersive 3D centerpiece
- Futuristic neon dark premium aesthetic
- Micro-interactions and delightful feedback
- Seamless multi-section "multi-page" feel in a single immersive scroll

## Credits / Tech

- Three.js burger modeling & lighting by Arena Agent
- All other components and design original

Enjoy the heat. 🔥

---

*Streeters Bar_Grill — American Heat. Street Flavor.*
