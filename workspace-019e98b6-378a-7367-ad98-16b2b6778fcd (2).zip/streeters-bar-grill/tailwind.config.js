/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        'brand-black': '#0B0B0F',
        'brand-orange': '#FF6A00',
        'brand-yellow': '#FFC300',
        'brand-gray': '#1A1A1F',
        'brand-light': '#2A2A30',
      },
      fontFamily: {
        'sans': ['Inter', 'system-ui', 'sans-serif'],
        'display': ['Inter', 'system-ui', 'sans-serif'],
      },
      boxShadow: {
        'neon-orange': '0 0 5px #FF6A00, 0 0 20px #FF6A00, 0 0 40px rgba(255, 106, 0, 0.5)',
        'neon-yellow': '0 0 5px #FFC300, 0 0 20px #FFC300, 0 0 40px rgba(255, 195, 0, 0.5)',
        'glass': '0 8px 32px 0 rgba(0, 0, 0, 0.37)',
      },
    },
  },
  plugins: [],
}