# 🔥 STREETERS BAR_GRILL — Website

**American Heat. Street Flavor.**

A cinematic, futuristic 3D restaurant website built with HTML5, CSS3, Three.js, and vanilla JavaScript.

---

## 🚀 How to Run

### Option 1: Direct Browser
Just open `index.html` in any modern browser. No build step needed.

### Option 2: Local Server (Recommended for best experience)
```bash
# Python
python -m http.server 8080

# Node.js
npx serve .

# VS Code: Use "Live Server" extension
```
Then open: `http://localhost:8080`

---

## 📁 Project Structure

```
streeters/
├── index.html              # Main entry point
├── styles/
│   └── main.css            # All styles (CSS Variables, animations, layout)
├── scripts/
│   ├── menu-data.js        # Full menu data (9 categories, 50+ items)
│   ├── three-burger.js     # Three.js 3D burger with mouse parallax
│   ├── particles.js        # Background particles + animated grid
│   └── app.js              # Navigation, reviews, tilt, scroll reveal
└── README.md
```

---

## ✨ Features

| Feature | Status |
|---|---|
| 3D Burger (Three.js) | ✅ Auto-rotate + Mouse Parallax |
| Neon Particle Background | ✅ Animated CSS + Canvas |
| Full Menu (9 categories) | ✅ 50+ items with filter |
| 3D Tilt Cards | ✅ Mouse-responsive |
| Scroll Reveal Animations | ✅ IntersectionObserver |
| Custom Neon Cursor | ✅ |
| Review System (Frontend) | ✅ Add + display reviews |
| Star Rating UI | ✅ Interactive |
| WhatsApp + Phone CTA | ✅ |
| Fully Responsive | ✅ Mobile optimized |
| Glassmorphism Design | ✅ |

---

## 🎨 Brand Colors

| Color | Hex |
|---|---|
| Deep Black | `#0B0B0F` |
| Neon Orange | `#FF6A00` |
| Electric Yellow | `#FFC300` |

---

## 🛠 Technologies

- **HTML5** — Semantic structure
- **CSS3** — Custom properties, animations, glassmorphism, clip-path
- **Three.js r128** — 3D burger model with realistic lighting
- **Vanilla JS ES6+** — No framework dependencies
- **Google Fonts** — Bebas Neue, Barlow Condensed, Rajdhani

---

## 📱 To Replace Placeholders

- **Phone number**: Search `+15551234567` → replace with real number
- **WhatsApp link**: Update `wa.me/15551234567`  
- **Address**: Search `123 Main Street` → replace
- **Logo**: Replace `.logo-mark` with `<img src="logo.png">`

---

## 🔧 Customization

Add items to `scripts/menu-data.js` following the existing structure:
```js
{ name: 'Item Name', price: 15, desc: 'Description', emoji: '🍔', tag: 'HOT' }
```

---

*Built for Streeters Bar_Grill © 2025*
