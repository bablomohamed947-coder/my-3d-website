// ═══════════════════════════════════════
// STREETERS — PARTICLES & BG CANVAS
// ═══════════════════════════════════════

(function () {
  // ── BACKGROUND CANVAS GRID ──
  const bgCanvas = document.getElementById('bgCanvas');
  if (bgCanvas) {
    const ctx = bgCanvas.getContext('2d');
    let w, h, t = 0;

    function resizeBg() {
      w = bgCanvas.width = window.innerWidth;
      h = bgCanvas.height = window.innerHeight;
    }
    resizeBg();
    window.addEventListener('resize', resizeBg);

    function drawBg() {
      requestAnimationFrame(drawBg);
      ctx.clearRect(0, 0, w, h);
      t += 0.004;

      // Grid lines
      ctx.strokeStyle = 'rgba(255,106,0,0.07)';
      ctx.lineWidth = 1;
      const gridSize = 60;
      const offsetX = (t * 20) % gridSize;
      const offsetY = (t * 10) % gridSize;

      for (let x = -gridSize + offsetX; x < w + gridSize; x += gridSize) {
        ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, h);
        ctx.stroke();
      }
      for (let y = -gridSize + offsetY; y < h + gridSize; y += gridSize) {
        ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y);
        ctx.stroke();
      }

      // Radial glow
      const grad = ctx.createRadialGradient(w * 0.7, h * 0.5, 0, w * 0.7, h * 0.5, w * 0.4);
      grad.addColorStop(0, 'rgba(255,106,0,0.06)');
      grad.addColorStop(1, 'transparent');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, w, h);
    }
    drawBg();
  }

  // ── FLOATING PARTICLES ──
  const container = document.getElementById('particles');
  if (!container) return;

  const COUNT = 40;
  const particles = [];

  for (let i = 0; i < COUNT; i++) {
    const p = document.createElement('div');
    const size = Math.random() * 4 + 1;
    const isOrange = Math.random() > 0.5;
    const startX = Math.random() * 100;
    const startY = Math.random() * 100;
    const duration = 8 + Math.random() * 12;
    const delay = Math.random() * -15;
    const drift = (Math.random() - 0.5) * 60;

    p.style.cssText = `
      position: absolute;
      left: ${startX}%;
      top: ${startY}%;
      width: ${size}px;
      height: ${size}px;
      border-radius: 50%;
      background: ${isOrange ? '#FF6A00' : '#FFC300'};
      box-shadow: 0 0 ${size * 3}px ${isOrange ? 'rgba(255,106,0,0.8)' : 'rgba(255,195,0,0.8)'};
      opacity: 0;
      pointer-events: none;
      animation: particleFloat ${duration}s ${delay}s ease-in-out infinite;
      --drift: ${drift}px;
    `;
    container.appendChild(p);
    particles.push(p);
  }

  // Inject keyframes
  const style = document.createElement('style');
  style.textContent = `
    @keyframes particleFloat {
      0%   { opacity: 0; transform: translateY(0) translateX(0) scale(0.5); }
      15%  { opacity: 1; }
      85%  { opacity: 0.6; }
      100% { opacity: 0; transform: translateY(-120px) translateX(var(--drift)) scale(1.2); }
    }
  `;
  document.head.appendChild(style);
})();
