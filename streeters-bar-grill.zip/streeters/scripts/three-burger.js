// ═══════════════════════════════════════
// STREETERS — THREE.JS 3D BURGER
// ═══════════════════════════════════════

(function () {
  if (typeof THREE === 'undefined') return;

  const canvas = document.getElementById('burgerCanvas');
  if (!canvas) return;

  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.2;

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(45, 1, 0.1, 100);
  camera.position.set(0, 0.5, 5);

  // ── RESIZE ──
  function resize() {
    const container = document.getElementById('burger3d-container');
    if (!container) return;
    const w = container.clientWidth;
    const h = container.clientHeight;
    renderer.setSize(w, h);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
  }
  resize();
  window.addEventListener('resize', resize);

  // ── LIGHTING ──
  const ambient = new THREE.AmbientLight(0xffffff, 0.3);
  scene.add(ambient);

  const keyLight = new THREE.SpotLight(0xff6a00, 4, 20, Math.PI / 4, 0.4, 1);
  keyLight.position.set(4, 6, 4);
  keyLight.castShadow = true;
  scene.add(keyLight);

  const fillLight = new THREE.PointLight(0xffc300, 2, 15);
  fillLight.position.set(-4, 2, 2);
  scene.add(fillLight);

  const rimLight = new THREE.PointLight(0xff6a00, 1.5, 10);
  rimLight.position.set(0, -3, -4);
  scene.add(rimLight);

  const topLight = new THREE.DirectionalLight(0xffffff, 1);
  topLight.position.set(0, 8, 2);
  scene.add(topLight);

  // ── BURGER BUILDER ──
  const burgerGroup = new THREE.Group();
  scene.add(burgerGroup);

  function createLayer(config) {
    const group = new THREE.Group();
    const { type, color, width, height, y, roughness = 0.7, metalness = 0.1 } = config;

    let geo;
    if (type === 'bun') {
      // Rounded bun shape using sphere + cylinder
      const sphere = new THREE.SphereGeometry(width, 32, 16, 0, Math.PI * 2, 0, Math.PI / 2);
      const cyl = new THREE.CylinderGeometry(width, width * 0.95, height * 0.3, 32);
      const mat = new THREE.MeshStandardMaterial({ color, roughness, metalness });
      const sphereMesh = new THREE.Mesh(sphere, mat);
      const cylMesh = new THREE.Mesh(cyl, mat);
      sphereMesh.position.y = height * 0.3 / 2;
      sphereMesh.scale.y = 0.75;
      group.add(sphereMesh);
      group.add(cylMesh);
      group.position.y = y;
      return group;
    } else if (type === 'patty') {
      geo = new THREE.CylinderGeometry(width, width * 0.98, height, 32);
      // Add slight edge bump for realism
    } else if (type === 'lettuce') {
      // Wavy lettuce using plane
      const shape = [];
      for (let i = 0; i < 32; i++) {
        const angle = (i / 32) * Math.PI * 2;
        const r = width + Math.sin(angle * 6) * 0.08;
        shape.push(new THREE.Vector2(r * Math.cos(angle), r * Math.sin(angle)));
      }
      geo = new THREE.LatheGeometry([new THREE.Vector2(width, 0), new THREE.Vector2(width * 1.1, height)], 32);
    } else if (type === 'cheese') {
      geo = new THREE.BoxGeometry(width * 2, height, width * 2);
    } else {
      geo = new THREE.CylinderGeometry(width, width, height, 32);
    }

    const mat = new THREE.MeshStandardMaterial({ color, roughness, metalness });
    if (type === 'patty') {
      // Bump texture simulation via roughness map
      mat.roughness = 0.85;
      mat.metalness = 0.05;
    }
    const mesh = new THREE.Mesh(geo, mat);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    group.add(mesh);
    group.position.y = y;
    return group;
  }

  // Build burger layers (bottom to top)
  const layers = [
    // Bottom bun
    { type: 'cylinder', color: 0xc8720a, width: 0.82, height: 0.22, y: -0.9, roughness: 0.8 },
    // Bottom sesame-bun base
    { type: 'bun', color: 0xd4821a, width: 0.82, height: 0.3, y: -0.65, roughness: 0.75 },
    // Sauce layer (red)
    { type: 'cylinder', color: 0xcc2200, width: 0.8, height: 0.06, y: -0.35, roughness: 0.9, metalness: 0 },
    // Lettuce
    { type: 'cylinder', color: 0x3d8b2c, width: 0.92, height: 0.1, y: -0.28, roughness: 0.95 },
    // Tomato
    { type: 'cylinder', color: 0xff3322, width: 0.78, height: 0.09, y: -0.17, roughness: 0.85 },
    // Cheese
    { type: 'cheese', color: 0xffa500, width: 0.48, height: 0.07, y: -0.06, roughness: 0.8 },
    // Patty 1
    { type: 'patty', color: 0x4a2008, width: 0.80, height: 0.22, y: 0.05, roughness: 0.85 },
    // Onion
    { type: 'cylinder', color: 0xd4a0c8, width: 0.78, height: 0.06, y: 0.18, roughness: 0.9 },
    // Patty 2
    { type: 'patty', color: 0x3d1a06, width: 0.80, height: 0.22, y: 0.30, roughness: 0.85 },
    // Cheese 2
    { type: 'cheese', color: 0xffb300, width: 0.48, height: 0.07, y: 0.44, roughness: 0.8 },
    // Sauce top
    { type: 'cylinder', color: 0xffdd44, width: 0.79, height: 0.06, y: 0.52, roughness: 0.9 },
    // Top bun base
    { type: 'cylinder', color: 0xd4821a, width: 0.82, height: 0.15, y: 0.60, roughness: 0.75 },
  ];

  layers.forEach(cfg => burgerGroup.add(createLayer(cfg)));

  // Top bun (dome)
  const topBunGeo = new THREE.SphereGeometry(0.85, 32, 16, 0, Math.PI * 2, 0, Math.PI / 1.8);
  const topBunMat = new THREE.MeshStandardMaterial({ color: 0xd4821a, roughness: 0.75, metalness: 0.08 });
  const topBun = new THREE.Mesh(topBunGeo, topBunMat);
  topBun.position.y = 0.72;
  topBun.scale.y = 0.85;
  topBun.castShadow = true;
  burgerGroup.add(topBun);

  // Sesame seeds on top bun
  const sesameGeo = new THREE.SphereGeometry(0.04, 8, 8);
  const sesameMat = new THREE.MeshStandardMaterial({ color: 0xf5e6b0, roughness: 0.6 });
  const sesamePositions = [
    [0, 0], [0.28, 0.1], [-0.25, 0.15], [0.1, -0.3],
    [-0.15, -0.28], [0.35, -0.15], [-0.35, -0.1]
  ];
  sesamePositions.forEach(([ox, oz]) => {
    const seed = new THREE.Mesh(sesameGeo, sesameMat);
    const angle = Math.atan2(oz, ox);
    const r = Math.sqrt(ox * ox + oz * oz);
    const elevation = Math.sqrt(Math.max(0, 0.85 * 0.85 - r * r)) * 0.85;
    seed.position.set(ox, 0.72 + elevation + 0.03, oz);
    seed.rotation.z = angle + Math.PI / 4;
    burgerGroup.add(seed);
  });

  // Plate / shadow disc
  const plateGeo = new THREE.CylinderGeometry(1.1, 1.0, 0.04, 32);
  const plateMat = new THREE.MeshStandardMaterial({
    color: 0x1a1a2e, roughness: 0.3, metalness: 0.6,
  });
  const plate = new THREE.Mesh(plateGeo, plateMat);
  plate.position.y = -1.02;
  plate.receiveShadow = true;
  burgerGroup.add(plate);

  // Glow disc under burger
  const glowGeo = new THREE.CircleGeometry(1.2, 32);
  const glowMat = new THREE.MeshBasicMaterial({
    color: 0xff6a00,
    transparent: true, opacity: 0.08,
    side: THREE.DoubleSide
  });
  const glowDisc = new THREE.Mesh(glowGeo, glowMat);
  glowDisc.rotation.x = -Math.PI / 2;
  glowDisc.position.y = -1.0;
  burgerGroup.add(glowDisc);

  burgerGroup.position.y = -0.3;

  // ── MOUSE PARALLAX ──
  let mouseX = 0, mouseY = 0;
  let targetRotX = 0, targetRotY = 0;

  window.addEventListener('mousemove', e => {
    mouseX = (e.clientX / window.innerWidth - 0.5) * 2;
    mouseY = (e.clientY / window.innerHeight - 0.5) * 2;
  });

  // ── ANIMATE ──
  const clock = new THREE.Clock();
  let frame;

  function animate() {
    frame = requestAnimationFrame(animate);
    const t = clock.getElapsedTime();

    // Auto rotate
    burgerGroup.rotation.y = t * 0.4;

    // Mouse parallax tilt
    targetRotX += (-mouseY * 0.25 - targetRotX) * 0.05;
    targetRotY += (mouseX * 0.15 - targetRotY) * 0.05;
    burgerGroup.rotation.x = targetRotX;

    // Float animation
    burgerGroup.position.y = -0.3 + Math.sin(t * 1.2) * 0.08;

    // Pulsing lights
    keyLight.intensity = 3.5 + Math.sin(t * 2) * 0.5;
    fillLight.intensity = 1.8 + Math.sin(t * 1.5 + 1) * 0.3;
    glowDisc.material.opacity = 0.06 + Math.sin(t * 2) * 0.03;

    renderer.render(scene, camera);
  }

  animate();

  // Stop when not on home
  window.addEventListener('sectionChange', e => {
    if (e.detail !== 'home') {
      cancelAnimationFrame(frame);
    } else {
      animate();
    }
  });

  window._burgerRenderer = renderer;
})();
