// ═══════════════════════════════════════
// STREETERS BAR_GRILL — MAIN APP
// ═══════════════════════════════════════

// ── CUSTOM CURSOR ──
const cursor = document.getElementById('cursor');
const cursorTrail = document.getElementById('cursor-trail');
let cx = 0, cy = 0, tx = 0, ty = 0;

document.addEventListener('mousemove', e => {
  cx = e.clientX; cy = e.clientY;
  cursor.style.left = cx + 'px';
  cursor.style.top = cy + 'px';
});

(function moveCursorTrail() {
  tx += (cx - tx) * 0.12;
  ty += (cy - ty) * 0.12;
  cursorTrail.style.left = tx + 'px';
  cursorTrail.style.top = ty + 'px';
  requestAnimationFrame(moveCursorTrail);
})();

document.querySelectorAll('a, button, .menu-item, .filter-btn, .star').forEach(el => {
  el.addEventListener('mouseenter', () => {
    cursor.style.transform = 'translate(-50%,-50%) scale(2)';
    cursor.style.background = '#FFC300';
    cursorTrail.style.transform = 'translate(-50%,-50%) scale(1.5)';
  });
  el.addEventListener('mouseleave', () => {
    cursor.style.transform = 'translate(-50%,-50%) scale(1)';
    cursor.style.background = '#FF6A00';
    cursorTrail.style.transform = 'translate(-50%,-50%) scale(1)';
  });
});

// ── SCROLL NAV ──
window.addEventListener('scroll', () => {
  const nav = document.getElementById('navbar');
  nav.classList.toggle('scrolled', window.scrollY > 50);
  updateActiveNav();
});

function updateActiveNav() {
  const sections = ['home', 'menu', 'reviews', 'order'];
  let current = 'home';
  sections.forEach(id => {
    const el = document.getElementById(id);
    if (!el) return;
    if (window.scrollY >= el.offsetTop - 200) current = id;
  });
  document.querySelectorAll('.nav-link').forEach(l => {
    l.classList.toggle('active', l.dataset.page === current);
  });
}

function scrollToSection(id) {
  const el = document.getElementById(id);
  if (el) el.scrollIntoView({ behavior: 'smooth' });
}

// Nav links
document.querySelectorAll('.nav-link').forEach(link => {
  link.addEventListener('click', e => {
    e.preventDefault();
    scrollToSection(link.dataset.page);
  });
});
document.querySelector('.nav-logo').addEventListener('click', () => scrollToSection('home'));

// Mobile nav toggle
document.getElementById('navBurger').addEventListener('click', () => {
  const links = document.querySelector('.nav-links');
  if (!links) return;
  links.style.display = links.style.display === 'flex' ? 'none' : 'flex';
  links.style.flexDirection = 'column';
  links.style.position = 'fixed';
  links.style.top = '80px';
  links.style.left = '0';
  links.style.right = '0';
  links.style.background = 'rgba(11,11,15,0.97)';
  links.style.padding = '30px';
  links.style.gap = '24px';
  links.style.borderBottom = '1px solid rgba(255,106,0,0.3)';
  links.style.zIndex = '999';
});

// ── BUILD MENU ──
function buildMenu(filter = 'all') {
  const container = document.getElementById('menuContainer');
  if (!container || !window.MENU_DATA) return;
  container.innerHTML = '';

  const sectionDesc = {
    appetizers: 'Start the fire right.',
    bowls: 'Fresh. Bold. Satisfying.',
    sandwiches: 'Stacked and serious.',
    burgers: 'The real deal.',
    flatbreads: 'Thin, crispy, loaded.',
    soup: 'Warm your soul.',
    kids: 'Little ones, big flavors.',
    tacos: 'Street-style perfection.',
    others: 'Seasonal and market-fresh.'
  };

  MENU_DATA.forEach((section, si) => {
    if (filter !== 'all' && section.cat !== filter) return;

    const sectionEl = document.createElement('div');
    sectionEl.className = 'menu-section reveal';
    sectionEl.style.animationDelay = `${si * 0.1}s`;

    const itemsHTML = section.items.map(item => `
      <div class="menu-item" style="animation-delay:${Math.random() * 0.3}s">
        <span class="item-emoji">${item.emoji}</span>
        <div class="item-name">${item.name}</div>
        <div class="item-desc">${item.desc}</div>
        <div class="item-footer">
          <div class="item-price">${item.price ? '$' + item.price : 'ASK US'}</div>
          ${item.tag ? `<div class="item-tag">${item.tag}</div>` : ''}
        </div>
      </div>
    `).join('');

    sectionEl.innerHTML = `
      <div class="section-header">
        <span class="section-num">${section.num}</span>
        <h3 class="section-title">${section.emoji} ${section.title}</h3>
      </div>
      <p style="font-family:var(--font-body);color:var(--white2);margin-bottom:28px;letter-spacing:2px;font-size:14px">${sectionDesc[section.id] || ''}</p>
      <div class="menu-grid">${itemsHTML}</div>
    `;
    container.appendChild(sectionEl);
  });

  initReveal();
  initTiltCards();
}

buildMenu();

// Filter buttons
document.querySelectorAll('.filter-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    buildMenu(btn.dataset.cat);
  });
});

// ── REVIEWS DATA ──
const REVIEWS_DEFAULT = [
  { name: 'Marcus T.', rating: 5, text: 'The Manager Special is hands down the best burger I\'ve ever had. The bacon jam alone is worth the trip.', date: 'May 2025' },
  { name: 'Sarah L.', rating: 5, text: 'Incredible atmosphere and even better food. The Steak Bites starter were phenomenal — perfectly seared.', date: 'April 2025' },
  { name: 'Jordan K.', rating: 5, text: 'Brought my whole crew for game night. The Jumbo Wings and Elote Dip disappeared in minutes. Absolute fire!', date: 'March 2025' },
  { name: 'Priya M.', rating: 4, text: 'The Guajillo Steak Flatbread blew my mind. Perfectly spiced, great crust, generous toppings. Will be back!', date: 'May 2025' },
  { name: 'Chris B.', rating: 5, text: 'Best American food experience in the city. The Streeters Stacker lives up to the hype — absolutely stacked!', date: 'April 2025' },
  { name: 'Amara N.', rating: 5, text: 'Duck Bacon Wontons are dangerously addictive. The whole vibe of this place is just ✨ immaculate.', date: 'March 2025' },
];

let userReviews = [];
let userRating = 0;

function buildReviews() {
  const grid = document.getElementById('reviewsGrid');
  if (!grid) return;
  const all = [...REVIEWS_DEFAULT, ...userReviews];
  grid.innerHTML = all.map((r, i) => `
    <div class="review-card reveal" style="animation-delay:${i * 0.08}s">
      <div class="review-stars">${'★'.repeat(r.rating)}${'☆'.repeat(5 - r.rating)}</div>
      <p class="review-text">${r.text}</p>
      <div class="review-author">
        <div class="review-avatar">${r.name[0]}</div>
        <div>
          <div class="review-name">${r.name}</div>
          <div class="review-date">${r.date}</div>
        </div>
      </div>
    </div>
  `).join('');
  initReveal();
}

buildReviews();

// Stars input
document.querySelectorAll('.star').forEach(star => {
  star.addEventListener('click', () => {
    userRating = parseInt(star.dataset.v);
    document.querySelectorAll('.star').forEach((s, i) => {
      s.classList.toggle('active', i < userRating);
    });
  });
  star.addEventListener('mouseenter', () => {
    const v = parseInt(star.dataset.v);
    document.querySelectorAll('.star').forEach((s, i) => {
      s.style.color = i < v ? '#FFC300' : 'rgba(255,255,255,0.15)';
    });
  });
  star.addEventListener('mouseleave', () => {
    document.querySelectorAll('.star').forEach((s, i) => {
      s.style.color = i < userRating ? '#FFC300' : 'rgba(255,255,255,0.15)';
    });
  });
});

function submitReview() {
  const name = document.getElementById('rName').value.trim();
  const text = document.getElementById('rText').value.trim();
  if (!name || !text || !userRating) {
    showToast('Please fill in all fields and select a rating!', 'error');
    return;
  }
  const now = new Date();
  const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  userReviews.unshift({ name, rating: userRating, text, date: `${months[now.getMonth()]} ${now.getFullYear()}` });
  buildReviews();
  document.getElementById('rName').value = '';
  document.getElementById('rText').value = '';
  userRating = 0;
  document.querySelectorAll('.star').forEach(s => s.classList.remove('active'));
  showToast('Review submitted! Thank you! 🔥');
  document.getElementById('reviewsGrid').scrollIntoView({ behavior: 'smooth' });
}

window.submitReview = submitReview;

// ── TOAST NOTIFICATION ──
function showToast(msg, type = 'success') {
  const toast = document.createElement('div');
  toast.style.cssText = `
    position: fixed; bottom: 30px; left: 50%; transform: translateX(-50%);
    background: ${type === 'error' ? '#cc2200' : 'var(--orange)'};
    color: ${type === 'error' ? '#fff' : '#0B0B0F'};
    font-family: var(--font-ui); font-weight: 700;
    font-size: 13px; letter-spacing: 3px;
    padding: 16px 36px;
    clip-path: polygon(10px 0%, 100% 0%, calc(100% - 10px) 100%, 0% 100%);
    z-index: 9999;
    animation: toastIn 0.4s ease, toastOut 0.4s ease 2.6s both;
    pointer-events: none;
  `;
  toast.textContent = msg;
  document.body.appendChild(toast);

  const s = document.createElement('style');
  s.textContent = `
    @keyframes toastIn { from { opacity:0; transform: translateX(-50%) translateY(20px); } to { opacity:1; transform: translateX(-50%) translateY(0); } }
    @keyframes toastOut { to { opacity:0; transform: translateX(-50%) translateY(20px); } }
  `;
  document.head.appendChild(s);
  setTimeout(() => toast.remove(), 3200);
}

// ── SCROLL REVEAL ──
function initReveal() {
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
      }
    });
  }, { threshold: 0.1, rootMargin: '0px 0px -50px 0px' });

  document.querySelectorAll('.reveal').forEach(el => observer.observe(el));
}
initReveal();

// ── 3D TILT CARDS ──
function initTiltCards() {
  document.querySelectorAll('.menu-item').forEach(card => {
    card.addEventListener('mousemove', e => {
      const rect = card.getBoundingClientRect();
      const x = (e.clientX - rect.left) / rect.width - 0.5;
      const y = (e.clientY - rect.top) / rect.height - 0.5;
      card.style.transform = `
        translateY(-8px)
        rotateX(${-y * 12}deg)
        rotateY(${x * 12}deg)
        scale(1.02)
      `;
    });
    card.addEventListener('mouseleave', () => {
      card.style.transform = '';
    });
  });
}
initTiltCards();

// ── SECTION CHANGE EVENT ──
const sectionObserver = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      window.dispatchEvent(new CustomEvent('sectionChange', { detail: entry.target.id }));
    }
  });
}, { threshold: 0.3 });

['home', 'menu', 'reviews', 'order'].forEach(id => {
  const el = document.getElementById(id);
  if (el) sectionObserver.observe(el);
});

// ── PAGE SECTIONS REVEAL ──
document.querySelectorAll('.menu-section, .review-card, .order-card, .info-item').forEach(el => {
  el.classList.add('reveal');
});
initReveal();
