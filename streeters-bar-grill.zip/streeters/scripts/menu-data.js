// ═══════════════════════════════════════
// STREETERS BAR_GRILL — MENU DATA
// ═══════════════════════════════════════

const MENU_DATA = [
  {
    id: 'appetizers',
    cat: 'appetizers',
    num: '01',
    title: 'Appetizers',
    emoji: '🔥',
    items: [
      { name: 'Steak Bites', price: 17, desc: 'Tender beef cubes, seared hot with chimichurri dipping sauce', emoji: '🥩', tag: 'POPULAR' },
      { name: 'Corn Ribs', price: 11, desc: 'Crispy corn on the cob sliced into ribs, elote-style seasoning', emoji: '🌽', tag: '' },
      { name: 'Duck Bacon Wontons', price: 13, desc: 'Crispy wontons stuffed with duck confit and smoky bacon', emoji: '🥟', tag: 'CHEF\'S PICK' },
      { name: 'Creamery Curds', price: 12, desc: 'Fresh fried cheese curds with a golden crust, ranch dip', emoji: '🧀', tag: '' },
      { name: 'Streeters Spuds', price: 7, desc: 'Crispy seasoned potato wedges with our secret house sauce', emoji: '🥔', tag: '' },
      { name: 'Fried Pickles \'N\' Peppers', price: 11, desc: 'Beer-battered pickles and peppers with spicy ranch', emoji: '🫙', tag: '' },
      { name: 'Jumbo Wings', price: 12, desc: 'Oversized wings, choice of Buffalo, BBQ or dry rub', emoji: '🍗', tag: 'POPULAR' },
      { name: 'Elote Dip', price: 10, desc: 'Street corn dip with cotija cheese, lime and chili powder', emoji: '🫕', tag: '' },
      { name: 'Cheesy Focaccia', price: 12, desc: 'House-baked focaccia with garlic butter and three cheeses', emoji: '🍞', tag: '' },
    ]
  },
  {
    id: 'bowls',
    cat: 'bowls',
    num: '02',
    title: 'Bowls & Greens',
    emoji: '🥗',
    items: [
      { name: 'Big Bite Bowl', price: 17, desc: 'Loaded grain bowl with steak, roasted veggies and tahini', emoji: '🥗', tag: 'POPULAR' },
      { name: 'Caesar', price: 11, desc: 'Classic Caesar with house-made dressing, croutons and parmesan', emoji: '🥬', tag: '' },
      { name: 'BLT Bowl', price: 15, desc: 'Crispy bacon, cherry tomatoes, romaine, avocado, buttermilk ranch', emoji: '🍅', tag: '' },
      { name: 'Side Caesar', price: 6, desc: 'Small classic Caesar — the perfect sidekick', emoji: '🥬', tag: '' },
      { name: 'Berry Crunch Salad', price: 14, desc: 'Mixed greens, seasonal berries, candied pecans, balsamic', emoji: '🍓', tag: '' },
      { name: 'Side Salad', price: 6, desc: 'Garden greens, tomato, cucumber, your choice of dressing', emoji: '🥙', tag: '' },
    ]
  },
  {
    id: 'sandwiches',
    cat: 'sandwiches',
    num: '03',
    title: 'Sandwiches',
    emoji: '🥪',
    items: [
      { name: 'Bruschetta Hammy', price: 15, desc: 'Ham, fresh bruschetta, fresh mozzarella on toasted ciabatta', emoji: '🥪', tag: '' },
      { name: 'Porky Pig', price: 15, desc: 'Pulled pork, coleslaw, pickled onions, chipotle BBQ sauce', emoji: '🐷', tag: '' },
      { name: 'The Shift Meal', price: 16, desc: 'Steak, caramelized onions, cheddar, on toasted sourdough', emoji: '🥩', tag: 'STAFF FAVE' },
      { name: 'Streeters Stacker', price: 18, desc: 'Triple-stacked smash with special sauce — our signature', emoji: '🍔', tag: 'SIGNATURE' },
      { name: 'The Toasty Chicken', price: 15, desc: 'Crispy fried chicken, pickles, honey mustard on brioche', emoji: '🍗', tag: 'POPULAR' },
    ]
  },
  {
    id: 'burgers',
    cat: 'burgers',
    num: '04',
    title: 'Burgers',
    emoji: '🍔',
    items: [
      { name: 'The Fun-Gi', price: 15, desc: 'Beef patty, sautéed mushrooms, Swiss, truffle aioli', emoji: '🍄', tag: '' },
      { name: 'Boring Burger', price: 12, desc: 'Classic done right — beef, lettuce, tomato, onion, ketchup', emoji: '🍔', tag: '' },
      { name: 'Elote Burger', price: 15, desc: 'Beef smash, elote corn relish, cotija, chili crema', emoji: '🌽', tag: 'CHEF\'S PICK' },
      { name: 'Manager Special', price: 16, desc: 'Double smash, bacon jam, cheddar, fried onion rings', emoji: '🏆', tag: 'SIGNATURE' },
    ]
  },
  {
    id: 'flatbreads',
    cat: 'flatbreads',
    num: '05',
    title: 'Flatbreads',
    emoji: '🍕',
    items: [
      { name: 'The Campout', price: 14, desc: 'Smoked chicken, roasted peppers, gouda, campfire sauce', emoji: '🔥', tag: '' },
      { name: 'Guajillo Steak Flatbread', price: 16, desc: 'Thin-cut steak, guajillo chili base, pickled jalapeño', emoji: '🌶️', tag: 'SPICY' },
      { name: 'Bruschetta', price: 14, desc: 'Tomato, fresh basil, ricotta, balsamic glaze, olive oil', emoji: '🍅', tag: '' },
      { name: 'Philly Flatbread', price: 15, desc: 'Shaved ribeye, peppers, onions, provolone cheese sauce', emoji: '🥩', tag: 'POPULAR' },
      { name: 'Thats A Spicy Pickle', price: 18, desc: 'Spicy sausage, pickled peppers, habanero honey, mozzarella', emoji: '🌶️', tag: 'HOT 🔥' },
      { name: 'The Michelangelo', price: 17, desc: 'Prosciutto, arugula, parmesan, truffle oil, fig jam', emoji: '🎨', tag: 'PREMIUM' },
    ]
  },
  {
    id: 'soup',
    cat: 'all',
    num: '06',
    title: 'Soup & Salads',
    emoji: '🍲',
    items: [
      { name: 'White Chicken Chili', price: 5, desc: 'Creamy, slow-simmered white chili with tender chicken', emoji: '🍲', tag: '' },
      { name: 'Soup Du Jour', price: 5, desc: 'Ask your server for today\'s freshly made seasonal soup', emoji: '🥣', tag: 'DAILY' },
      { name: 'The Fainting Goat', price: 12, desc: 'Arugula, goat cheese, candied walnuts, lemon vinaigrette', emoji: '🐐', tag: '' },
      { name: 'Rodeo Salad', price: 15, desc: 'Steak, corn, black beans, avocado, chipotle ranch', emoji: '🤠', tag: '' },
      { name: 'Side Salad', price: 5, desc: 'Garden fresh greens with your choice of dressing', emoji: '🥗', tag: '' },
    ]
  },
  {
    id: 'kids',
    cat: 'kids',
    num: '07',
    title: 'Kids Menu',
    emoji: '⭐',
    items: [
      { name: 'Grilled Cheese', price: 7, desc: 'Golden grilled cheese on white bread with dipping sauce', emoji: '🧀', tag: '' },
      { name: 'Mac N Cheese', price: 7, desc: 'Creamy house-made macaroni and cheese, kids\' favorite', emoji: '🍝', tag: 'FAVE' },
      { name: 'Hamburger', price: 7, desc: 'Simple beef burger, bun, ketchup, the classic way', emoji: '🍔', tag: '' },
      { name: 'Cheeseburger', price: 7, desc: 'Classic hamburger with a slice of American cheese', emoji: '🍔', tag: '' },
    ]
  },
  {
    id: 'tacos',
    cat: 'tacos',
    num: '08',
    title: 'Tacos',
    emoji: '🌮',
    items: [
      { name: 'Carnitas', price: 5, desc: 'Slow-braised pork, salsa verde, onion, cilantro, lime', emoji: '🌮', tag: 'POPULAR' },
      { name: 'Chicken Asada', price: 5, desc: 'Marinated grilled chicken, pico de gallo, crema, avocado', emoji: '🐔', tag: '' },
      { name: 'Beef', price: 4, desc: 'Seasoned ground beef, shredded cheese, lettuce, tomato', emoji: '🥩', tag: '' },
    ]
  },
  {
    id: 'others',
    cat: 'all',
    num: '09',
    title: 'Others',
    emoji: '✨',
    items: [
      { name: 'Braised Beef', price: null, desc: 'Slow-braised tender beef, ask server for preparation today', emoji: '🥩', tag: 'MARKET PRICE' },
      { name: 'Pulled Pork', price: null, desc: 'House slow-smoked pulled pork, signature dry rub', emoji: '🐷', tag: 'MARKET PRICE' },
      { name: 'Chicken', price: null, desc: 'Grilled or fried whole chicken with your choice of sides', emoji: '🍗', tag: 'MARKET PRICE' },
      { name: 'Seafood', price: null, desc: 'Fresh catch of the day — ask your server for today\'s selection', emoji: '🦞', tag: 'MARKET PRICE' },
      { name: 'Coca-Cola', price: null, desc: 'Classic Coca-Cola products, fountain or canned', emoji: '🥤', tag: '' },
    ]
  },
];

window.MENU_DATA = MENU_DATA;
