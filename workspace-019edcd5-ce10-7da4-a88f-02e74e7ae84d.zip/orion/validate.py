#!/usr/bin/env python3
"""Structural validator for the generated n8n workflow."""
import json, sys
from collections import Counter

with open("/home/user/orion/Orion_Support_Hub.json") as f:
    wf = json.load(f)

errors, warns = [], []
nodes = wf.get("nodes", [])
conns = wf.get("connections", {})
names = {n["name"] for n in nodes}

# 1) top-level keys
for k in ["name", "nodes", "connections", "settings"]:
    if k not in wf:
        errors.append(f"missing top-level key: {k}")

# 2) duplicate names
dups = [n for n, c in Counter(n["name"] for n in nodes).items() if c > 1]
if dups:
    errors.append(f"duplicate node names: {dups}")

# 3) each node well-formed
REQUIRED = ["parameters", "id", "name", "type", "typeVersion", "position"]
for n in nodes:
    for k in REQUIRED:
        if k not in n:
            errors.append(f"node '{n.get('name','?')}' missing key: {k}")
    if not isinstance(n.get("position"), list) or len(n["position"]) != 2:
        errors.append(f"node '{n['name']}' bad position")
    if "settings" not in n:
        warns.append(f"node '{n['name']}' has no settings")

# 4) connections reference real nodes
for src, outs in conns.items():
    if src not in names:
        errors.append(f"connection source missing: {src}")
    for ctype, arr in outs.items():
        for group in arr:
            for c in group:
                if c["node"] not in names:
                    errors.append(f"connection target missing: {c['node']} (from {src})")

# 5) credential placeholders present
creds_found = set()
for n in nodes:
    for ck in (n.get("credentials") or {}):
        creds_found.add(ck)

# 6) trigger nodes present
triggers = [n for n in nodes if n["type"].endswith("Trigger") or n["type"].endswith("webhook")
            or n["type"].endswith("errorTrigger") or n["type"].endswith("scheduleTrigger")
            or n["type"].endswith("manualTrigger") or n["type"].endswith("emailReadImap")
            or n["type"].endswith("telegramTrigger")]

print("=" * 60)
print(f"WORKFLOW: {wf['name']}")
print(f"Nodes: {len(nodes)} | Connection sources: {len(conns)}")
print("-" * 60)
print(f"Triggers ({len(triggers)}):")
for t in triggers:
    print(f"   - {t['name']}  [{t['type']}]")
print("-" * 60)
print("Node type breakdown:")
for t, c in sorted(Counter(n["type"] for n in nodes).items(), key=lambda x: -x[1]):
    print(f"   {c:>2}  {t}")
print("-" * 60)
print(f"Credentials referenced ({len(creds_found)}): {sorted(creds_found)}")
print("-" * 60)
print(f"ERRORS: {len(errors)}")
for e in errors:
    print("   X", e)
print(f"WARNINGS: {len(warns)}")
for w in warns[:10]:
    print("   !", w)
print("=" * 60)
sys.exit(1 if errors else 0)
