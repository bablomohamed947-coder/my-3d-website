#!/usr/bin/env python3
"""
Generator for the "Orion Support Hub" enterprise n8n workflow.
Produces a single importable n8n workflow JSON.
"""
import json
import uuid

# ------------------------------------------------------------------ helpers
nodes_by_name = {}
conns = {}
ids = {}

def nid(name):
    ids.setdefault(name, str(uuid.uuid4()))
    return ids[name]

def add_node(name, ntype, typeVersion, position, parameters=None, credentials=None,
             notes=None, onError="continueRegularOutput", retry=True,
             maxTries=5, waitBetweenTries=5000, errorOutput=False):
    node = {
        "parameters": parameters or {},
        "id": nid(name),
        "name": name,
        "type": ntype,
        "typeVersion": typeVersion,
        "position": [position[0], position[1]],
        "notesInFlow": True if notes else False,
    }
    if credentials:
        node["credentials"] = credentials
    if notes:
        node["notes"] = notes
    settings = {}
    if retry:
        settings["retryOnFail"] = True
        settings["maxTries"] = maxTries
        settings["waitBetweenTries"] = waitBetweenTries
    settings["onError"] = "continueErrorOutput" if errorOutput else onError
    settings["alwaysOutputData"] = False
    node["settings"] = settings
    nodes_by_name[name] = node
    return node

def link(src, dst, out_index=0, in_index=0):
    conns.setdefault(src, {})
    main = conns[src].setdefault("main", [])
    while len(main) <= out_index:
        main.append([])
    if not any(c["node"] == dst for c in main[out_index]):
        main[out_index].append({"node": dst, "type": "main", "index": in_index})

def link_ai(src, dst, ctype):
    conns.setdefault(src, {})
    arr = conns[src].setdefault(ctype, [])
    if not arr:
        arr.append([])
    if not any(c["node"] == dst for c in arr[0]):
        arr[0].append({"node": dst, "type": ctype, "index": 0})

# ------------------------------------------------------------------ credentials
def cred(t, name, cid):
    """Return a properly wrapped n8n credential object keyed by type."""
    return {t: {"id": cid, "name": name}}

CRED = {
    "telegramApi": cred("telegramApi", "Orion Telegram Bot", "cred-telegram-bot"),
    "anthropicApi": cred("anthropicApi", "Orion Claude API Key", "cred-anthropic"),
    "openAiApi": cred("openAiApi", "Orion OpenAI API Key", "cred-openai"),
    "postgres": cred("postgres", "Orion PostgreSQL Database", "cred-postgres"),
    "smtp": cred("smtp", "Orion SMTP Outbound", "cred-smtp"),
    "imap": cred("imap", "Orion Support IMAP Inbox", "cred-imap"),
    "whatsappToken": cred("httpHeaderAuth", "Orion WhatsApp Cloud API", "cred-whatsapp"),
    "crmApi": cred("httpHeaderAuth", "Orion CRM API", "cred-crm"),
}

# ------------------------------------------------------------------ builders
def claude_body(system, user_expr, model="claude-sonnet-4-5-20250929", max_tokens=1024):
    obj = {
        "model": model,
        "max_tokens": max_tokens,
        "system": system,
        "messages": [{"role": "user", "content": "{{ " + user_expr + " }}"}],
    }
    return json.dumps(obj)

def anthropic_node(name, pos, system, user_expr, max_tokens=1024, error_output=True):
    params = {
        "method": "POST",
        "url": "https://api.anthropic.com/v1/messages",
        "authentication": "predefinedCredentialType",
        "nodeCredentialType": "anthropicApi",
        "sendHeaders": True,
        "headerParameters": {
            "parameters": [
                {"name": "anthropic-version", "value": "2023-06-01"},
                {"name": "content-type", "value": "application/json"},
            ]
        },
        "sendBody": True,
        "specifyBody": "json",
        "jsonBody": claude_body(system, user_expr, max_tokens=max_tokens),
        "options": {"response": {"response": {"fullResponse": False}}},
    }
    return add_node(name, "n8n-nodes-base.httpRequest", 4.2, pos, params,
                    CRED["anthropicApi"], errorOutput=error_output)

def pg_node(name, pos, query, error_output=False):
    return add_node(name, "n8n-nodes-base.postgres", 2.5, pos,
                    {"operation": "execute", "query": query, "options": {}},
                    CRED["postgres"], errorOutput=error_output)

def code_node(name, pos, js, error_output=False):
    return add_node(name, "n8n-nodes-base.code", 2, pos, {"jsCode": js},
                    errorOutput=error_output)

def http_node(name, pos, method, url, json_body=None, auth_type=None,
              cred_key=None, error_output=True):
    params = {"method": method, "url": url, "options": {}}
    if cred_key:
        params["authentication"] = "genericCredentialType"
        params["genericCredentialType"] = "httpHeaderAuth"
    if json_body:
        params["sendBody"] = True
        params["specifyBody"] = "json"
        params["jsonBody"] = json_body
    return add_node(name, "n8n-nodes-base.httpRequest", 4.2, pos, params,
                    CRED.get(cred_key) if cred_key else None, errorOutput=error_output)

NORMALIZE_JS = r"""
// Orion Support Hub - Multi-channel normalizer
const raw = $input.first().json;
let channel = 'webhook', customerId = '', name = '', phone = '', email = '';
let content = '', contentType = 'text', mediaUrl = '', messageId = '';

if (raw.message && raw.update_id) { // Telegram
  channel = 'telegram';
  const m = raw.message;
  customerId = String(m.chat?.id || '');
  name = [m.from?.first_name, m.from?.last_name].filter(Boolean).join(' ');
  username = m.from?.username || '';
  messageId = String(m.message_id || '');
  if (m.voice || m.audio) { contentType = 'voice'; mediaUrl = 'telegram-file://'+(m.voice?.file_id||m.audio?.file_id); }
  else if (m.photo) { contentType = 'image'; mediaUrl = m.photo[m.photo.length-1]?.file_id || ''; }
  else if (m.document) { contentType = m.document.mime_type?.includes('pdf') ? 'pdf' : 'document'; mediaUrl = m.document.file_id || ''; }
  else if (m.video) { contentType = 'video'; mediaUrl = m.video.file_id || ''; }
  content = m.caption || m.text || '';
} else if (raw.entry && raw.entry[0]?.changes?.[0]?.value?.messages) { // WhatsApp Cloud API
  channel = 'whatsapp';
  const v = raw.entry[0].changes[0].value;
  const msg = v.messages[0];
  customerId = msg.from || '';
  name = v.contacts?.[0]?.profile?.name || '';
  messageId = msg.id || '';
  if (msg.type === 'audio') { contentType='voice'; mediaUrl=msg.audio.id; }
  else if (msg.type==='image') { contentType='image'; mediaUrl=msg.image.id; content=msg.image.caption||''; }
  else if (msg.type==='document') { contentType=msg.document.mime_type?.includes('pdf')?'pdf':'document'; mediaUrl=msg.document.id; }
  else if (msg.type==='video') { contentType='video'; mediaUrl=msg.video.id; }
  else content = msg.text?.body || '';
} else if (raw.textHtml || raw.textPlain || raw.fromAddress) { // Email (IMAP)
  channel = 'email';
  email = raw.fromAddress || raw.from?.value?.[0]?.address || '';
  customerId = email;
  name = raw.from?.value?.[0]?.name || email;
  content = raw.textPlain || raw.textHtml || raw.subject || '';
  messageId = raw.messageId || '';
  if (raw.attachments?.length) {
    const a = raw.attachments[0];
    contentType = a.mimeType?.includes('pdf') ? 'pdf' : (a.mimeType?.startsWith('image') ? 'image' : 'document');
    mediaUrl = a.fileName || '';
  }
} else if (raw.event_type || raw.crm_event) { // CRM Events
  channel = 'crm';
  customerId = String(raw.customer_id || raw.contactId || '');
  content = raw.description || raw.event_type || 'CRM event';
  contentType = 'text';
} else { // Webhook API
  channel = raw.channel || 'webhook';
  customerId = String(raw.customer_id || raw.customerId || raw.chat_id || '');
  name = raw.name || raw.customer_name || '';
  phone = raw.phone || '';
  email = raw.email || '';
  content = raw.content || raw.message || JSON.stringify(raw);
  contentType = raw.content_type || (raw.image_url ? 'image' : (raw.voice_url ? 'voice' : 'text'));
  mediaUrl = raw.media_url || raw.image_url || raw.voice_url || '';
  messageId = raw.message_id || '';
}

return [{
  json: {
    channel, customerId, name, phone, email, username: typeof username !== 'undefined' ? username : '',
    content, contentType, mediaUrl, messageId,
    receivedAt: new Date().toISOString(),
    requestId: 'req_' + Math.random().toString(36).slice(2, 12)
  }
}];
"""

# ==================================================================
# STEP 1 - TRIGGERS (multi-channel intake)
# ==================================================================
add_node("Telegram Trigger", "n8n-nodes-base.telegramTrigger", 1.2,
         [-1800, -1000], {"updates": ["message"]}, CRED["telegramApi"],
         notes="Receives Telegram messages, voice, images, docs, video.",
         retry=False)

add_node("WhatsApp Trigger", "n8n-nodes-base.webhook", 2,
         [-1800, -500],
         {"httpMethod": "POST", "path": "orion-whatsapp",
          "responseMode": "responseNode", "options": {}},
         notes="WhatsApp Cloud API inbound webhook (text/voice/image/doc/video).",
         retry=False)

add_node("Email Trigger", "n8n-nodes-base.emailReadImap", 2.2,
         [-1800, 0],
         {"postProcessAction": "markAsRead",
          "format": "resolved", "options": {}},
         CRED["imap"],
         notes="Polls support inbox via IMAP; parses body + attachments.",
         retry=False)

add_node("Webhook API", "n8n-nodes-base.webhook", 2,
         [-1800, 500],
         {"httpMethod": "POST", "path": "orion-api",
          "responseMode": "responseNode", "options": {}},
         notes="Public REST endpoint for programmatic intake.",
         retry=False)

add_node("CRM Events", "n8n-nodes-base.webhook", 2,
         [-1800, 1000],
         {"httpMethod": "POST", "path": "orion-crm-events",
          "responseMode": "responseNode", "options": {}},
         notes="Receives CRM lifecycle events (ticket/contact/deal changes).",
         retry=False)

# ==================================================================
# STEP 2 + 3 - NORMALIZE & CONTENT TYPE DETECTION
# ==================================================================
add_node("Normalize Data", "n8n-nodes-base.code", 2, [-1350, 0],
         {"jsCode": NORMALIZE_JS},
         notes="Standardizes Telegram/WhatsApp/Email/Webhook/CRM into one schema.",
         retry=True, maxTries=3)

add_node("Detect Content Type", "n8n-nodes-base.switch", 2, [-1050, 0],
         {"dataType": "string", "value1": "={{ $json.contentType }}",
          "rules": {"rules": [
              {"value2": "voice", "outputKey": "Voice"},
              {"value2": "image", "outputKey": "Image"},
              {"value2": "pdf", "outputKey": "PDF"},
              {"value2": "document", "outputKey": "Document"},
              {"value2": "video", "outputKey": "Video"}]},
          "fallbackOutput": 1, "options": {}},
         notes="Routes by detected media type; text falls through to default.",
         retry=False)

# ==================================================================
# STEP 4 - VOICE PIPELINE
# ==================================================================
add_node("Download Voice", "n8n-nodes-base.httpRequest", 4.2, [-780, -900],
         {"method": "GET", "url": "={{ $json.mediaUrl || '' }}",
          "responseFormat": "file", "options": {}},
         notes="Fetches voice binary from channel storage.", errorOutput=True)

add_node("Speech to Text", "n8n-nodes-base.openAi", 1.6, [-510, -900],
         {"resource": "audio", "operation": "transcribe",
          "modelId": "whisper-1",
          "fileFieldName": "data", "options": {}},
         CRED["openAiApi"],
         notes="OpenAI Whisper transcription of voice messages.",
         errorOutput=True)
add_node("Extract Voice Intent", "n8n-nodes-base.httpRequest", 4.2, [-240, -900],
         {"method": "POST", "url": "https://api.anthropic.com/v1/messages",
          "authentication": "predefinedCredentialType",
          "nodeCredentialType": "anthropicApi",
          "sendHeaders": True,
          "headerParameters": {"parameters": [
              {"name": "anthropic-version", "value": "2023-06-01"},
              {"name": "content-type", "value": "application/json"}]},
          "sendBody": True, "specifyBody": "json",
          "jsonBody": claude_body(
              "You are an intent-extraction engine. Return JSON: {intent, category, urgency_1_to_5}.",
              "Transcript: $json.text + context: $json.content"),
          "options": {}},
         CRED["anthropicApi"],
         notes="Claude extracts intent + category from the transcript.",
         errorOutput=True)

# ==================================================================
# STEP 5 - IMAGE PIPELINE
# ==================================================================
add_node("Download Image", "n8n-nodes-base.httpRequest", 4.2, [-780, -500],
         {"method": "GET", "url": "={{ $json.mediaUrl || '' }}",
          "responseFormat": "file", "options": {}},
         notes="Fetches image binary.", errorOutput=True)
anthropic_node("Analyze Image", [-510, -500],
               "You are a multimodal vision analyst. Describe what the customer "
               "image shows relevant to a support context. Return concise findings.",
               "$json.content + (image attached as mediaUrl)",
               max_tokens=768)

# ==================================================================
# STEP 6 - PDF / DOCUMENT PIPELINE
# ==================================================================
add_node("Extract Document Text", "n8n-nodes-base.httpRequest", 4.2, [-780, -100],
         {"method": "POST",
          "url": "https://api.anthropic.com/v1/messages",
          "authentication": "predefinedCredentialType",
          "nodeCredentialType": "anthropicApi",
          "sendHeaders": True,
          "headerParameters": {"parameters": [
              {"name": "anthropic-version", "value": "2023-06-01"},
              {"name": "content-type", "value": "application/json"}]},
          "sendBody": True, "specifyBody": "json",
          "jsonBody": claude_body(
              "Extract all meaningful text from the provided document page(s). "
              "Preserve structure. Return plain text.",
              "Document reference: $json.mediaUrl ; caption: $json.content",
              max_tokens=2048),
          "options": {}},
         CRED["anthropicApi"],
         notes="Claude reads the document/PDF and extracts text.",
         errorOutput=True)
anthropic_node("Summarize Document", [-510, -100],
               "Summarize the extracted document for a support agent. "
               "Return: short summary, key points, action items.",
               "$json.text", max_tokens=768)

# ==================================================================
# STEP 6b - VIDEO PIPELINE (transcribe + describe)
# ==================================================================
add_node("Analyze Video", "n8n-nodes-base.openAi", 1.6, [-510, 250],
         {"resource": "audio", "operation": "transcribe",
          "modelId": "whisper-1", "fileFieldName": "data", "options": {}},
         CRED["openAiApi"],
         notes="Transcribes attached video audio track for context.",
         errorOutput=True)

# ==================================================================
# MERGE
# ==================================================================
add_node("Merge Channels", "n8n-nodes-base.merge", 2.2, [-240, 0],
         {"mode": "combine", "combineBy": "combineAll",
          "options": {}},
         notes="Reunifies all media pipelines + plain text into a single stream.",
         retry=False)

# ==================================================================
# STEP 7-10 - DATABASE LAYER
# ==================================================================
pg_node("Store Customer Info", [40, -560],
        "INSERT INTO customers (customer_id, name, phone, email, status, "
        "total_orders, last_activity) VALUES "
        "('{{ $json.customerId }}','{{ $json.name }}','{{ $json.phone }}',"
        "'{{ $json.email }}','active', 0, '{{ $json.receivedAt }}') "
        "ON CONFLICT (customer_id) DO UPDATE SET name=EXCLUDED.name, "
        "phone=EXCLUDED.phone, email=EXCLUDED.email, "
        "last_activity=EXCLUDED.last_activity;",
        error_output=True)

pg_node("Retrieve Customer Memory", [40, -260],
        "SELECT memory FROM memory WHERE customer_id = '{{ $json.customerId }}' "
        "LIMIT 1;", error_output=True)

pg_node("Retrieve Previous Orders", [40, 40],
        "SELECT order_id, order_details, status FROM orders "
        "WHERE customer_id = '{{ $json.customerId }}' ORDER BY order_id DESC LIMIT 20;",
        error_output=True)

pg_node("Retrieve Customer History", [40, 340],
        "SELECT message_id, content, category, timestamp FROM messages "
        "WHERE customer_id = '{{ $json.customerId }}' ORDER BY timestamp DESC LIMIT 50;",
        error_output=True)

pg_node("Search Knowledge Base", [340, -60],
        "SELECT faq, company_policies, product_information FROM knowledge_base "
        "WHERE document @@ to_tsquery('{{ $json.content }}') LIMIT 5;",
        error_output=True)

# ==================================================================
# STEP 11 - CLAUDE AI AGENT (langchain)
# ==================================================================
add_node("Claude AI Agent", "@n8n/n8n-nodes-langchain.agent", 2, [640, -60],
         {"agent": "toolsAgent", "promptType": "define",
          "text": "=Customer message:\n{{ $json.content }}\n\nCustomer: {{ $json.name }} ({{ $json.customerId }})\nChannel: {{ $json.channel }}",
          "options": {
              "systemMessage": "You are Orion, an enterprise-grade AI customer "
              "support agent. You reason step by step, are context aware, and "
              "polite. Use the available tools to look up orders, search the "
              "knowledge base, and open tickets. Decide a category from: "
              "general, sales, technical, billing, complaints. Always end your "
              "reply with a JSON block: {\"category\":\"...\",\"confidence\":0.x}."}},
         notes="Primary reasoning agent. Multi-step, context-aware, tool-using.",
         errorOutput=True)

add_node("Claude Chat Model", "@n8n/n8n-nodes-langchain.lmChatAnthropic", 1, [430, 180],
         {"model": "claude-sonnet-4-5-20250929",
          "options": {"maxTokensToSample": 2048, "temperature": 0.4}},
         CRED["anthropicApi"],
         notes="Anthropic Claude language model bound to the agent.")

add_node("Conversation Memory", "@n8n/n8n-nodes-langchain.memoryBufferWindow", 1, [640, 180],
         {"contextWindowLength": 100,
          "sessionId": "={{ $json.customerId }}"},
         notes="Rolling memory of the last 100 messages per customer.")

add_node("Knowledge Base Tool", "@n8n/n8n-nodes-langchain.toolHttpRequest", 1.1, [850, 180],
         {"name": "search_knowledge_base",
          "description": "Search company FAQ, policies and product docs.",
          "method": "GET",
          "url": "=https://kb.orion.internal/api/search?q={{$fromAI(\"query\")}}",
          "options": {}},
         notes="Agent tool: semantic KB lookup.")

add_node("Order Lookup Tool", "@n8n/n8n-nodes-langchain.toolCode", 1.1, [1060, 180],
         {"name": "lookup_orders", "description": "Fetch a customer's recent orders.",
          "jsCode": "const id = $fromAI('customer_id'); return [{json:{orders:[]}}];"},
         notes="Agent tool: retrieve order history.")

add_node("Ticket Tool", "@n8n/n8n-nodes-langchain.toolCode", 1.1, [1270, 180],
         {"name": "create_ticket", "description": "Create a support ticket in the CRM.",
          "jsCode": "const subject=$fromAI('subject'); return [{json:{ticketId:'TKT-'+Date.now()}}];"},
         notes="Agent tool: open tickets automatically.")

# ==================================================================
# ROUTING LAYER - 5 INTELLIGENT PATHS
# ==================================================================
add_node("Intelligent Routing", "n8n-nodes-base.switch", 2, [960, -60],
         {"dataType": "string", "value1": "={{ $json.category || 'general' }}",
          "rules": {"rules": [
              {"value2": "general", "outputKey": "General Support"},
              {"value2": "sales", "outputKey": "Sales"},
              {"value2": "technical", "outputKey": "Technical"},
              {"value2": "billing", "outputKey": "Billing"},
              {"value2": "complaints", "outputKey": "Complaints"}]},
          "fallbackOutput": 1, "options": {}},
         notes="Routes to one of 5 specialist paths by classified category.",
         retry=False)

PATHS = [
    ("General Support", "general", -1300,
     "Handle general support: FAQs, account, how-to. Be clear and helpful."),
    ("Sales", "sales", -650,
     "Answer sales questions: pricing, plans, demos, ROI, quotes."),
    ("Technical", "technical", 0,
     "Diagnose technical issues: bugs, errors, integrations, logs, steps."),
    ("Billing And Payments", "billing", 650,
     "Resolve billing: invoices, refunds, charges, subscription, receipts."),
    ("Complaints And Escalations", "complaints", 1300,
     "De-escalate complaints with empathy; flag SLA/escalation triggers."),
]

def priority_js(path_label):
    return r"""
const sentiment = ($json.sentiment || '').toLowerCase();
const content = ($json.content || '').toLowerCase();
let score = 2;
const red = ['urgent','asap','broken','down','cannot','error','angry','lawsuit','cancel','refund','unacceptable'];
if (red.some(w => content.includes(w))) score += 2;
if (sentiment.includes('negative') || sentiment.includes('angry')) score += 1;
if (sentiment.includes('very negative')) score += 1;
const priority = score >= 4 ? 'P1-Critical' : score === 3 ? 'P2-High' : 'P3-Normal';
return [{json:{...$json, priority, priorityScore: Math.min(score,5), path: '""" + path_label + r"""'}}];
"""

PA = lambda p: f"AI Analysis - {p}"
PD = lambda p: f"Priority Detection - {p}"
SA = lambda p: f"Sentiment Analysis - {p}"
SR = lambda p: f"Suggested Response - {p}"

for idx, (label, key, ly, desc) in enumerate(PATHS):
    bx = 1260
    anthropic_node(PA(label), [bx, ly],
                   f"You are a domain analyst for {label}. {desc} Produce a "
                   "concise root-cause/need analysis as JSON {analysis, category, severity_1_5}.",
                   "$json.content + ' || context: ' + ($json.text||'')")
    code_node(PD(label), [bx + 300, ly], priority_js(label))
    anthropic_node(SA(label), [bx + 600, ly],
                   "Classify customer sentiment. Return JSON "
                   "{sentiment: positive|neutral|negative|very negative, score_1_5, emotion}.",
                   "$json.content + ($json.text||'')")
    anthropic_node(SR(label), [bx + 900, ly],
                   f"Write the final customer-facing reply for a {label} case. "
                   "Tone: professional, empathetic, concise. End with the JSON tag.",
                   "$json.analysis + ' || ' + $json.content")

add_node("Merge Path Responses", "n8n-nodes-base.merge", 2.2, [2260, 0],
         {"mode": "combine", "combineBy": "combineAll", "options": {}},
         notes="Converges the 5 specialist paths.", retry=False)

# ==================================================================
# POST-PROCESSING - MEMORY / CRM / PAYMENTS
# ==================================================================
pg_node("Update Memory", [2520, -360],
        "INSERT INTO memory (customer_id, last_100_messages) VALUES "
        "('{{ $json.customerId }}', '{{ $json.content }}') "
        "ON CONFLICT (customer_id) DO UPDATE SET "
        "last_100_messages = memory.last_100_messages || E'\\n' || EXCLUDED.last_100_messages, "
        "updated_at = NOW();", error_output=True)

http_node("CRM: Create Ticket", [2520, -60], "POST",
          "https://crm.orion.internal/api/v1/tickets",
          json_body=json.dumps({"customer_id": "{{ $json.customerId }}",
                                "subject": "{{ $json.analysis }}",
                                "priority": "{{ $json.priority }}",
                                "category": "{{ $json.category }}",
                                "source": "{{ $json.channel }}"}),
          cred_key="crmApi", error_output=True)

http_node("CRM: Store AI Notes", [2520, 240], "POST",
          "https://crm.orion.internal/api/v1/tickets/{{ $json.ticketId || 'auto' }}/notes",
          json_body=json.dumps({"author": "Orion AI",
                                "note": "{{ $json.analysis }} | sentiment={{ $json.sentiment }} | confidence={{ $json.confidence }}"}),
          cred_key="crmApi", error_output=True)

add_node("Verify Payment Status", "n8n-nodes-base.postgres", 2.5, [2520, 540],
         {"operation": "execute",
          "query": "SELECT status, amount, currency FROM payments WHERE customer_id = '{{ $json.customerId }}' ORDER BY paid_at DESC LIMIT 5;",
          "options": {}}, CRED["postgres"],
         notes="Read-only payment status (no gateway connection).", errorOutput=True)

add_node("Track Invoices", "n8n-nodes-base.postgres", 2.5, [2820, 540],
         {"operation": "execute",
          "query": "SELECT invoice_id, total, due_date, status FROM invoices WHERE customer_id = '{{ $json.customerId }}' ORDER BY due_date DESC LIMIT 10;",
          "options": {}}, CRED["postgres"],
         notes="Invoice tracking lookup.", errorOutput=True)

# ==================================================================
# OUTPUT - ROUTE BACK TO CHANNEL
# ==================================================================
add_node("Select Output Channel", "n8n-nodes-base.switch", 2, [2820, -60],
         {"dataType": "string", "value1": "={{ $json.channel }}",
          "rules": {"rules": [
              {"value2": "telegram", "outputKey": "Telegram"},
              {"value2": "whatsapp", "outputKey": "WhatsApp"},
              {"value2": "email", "outputKey": "Email"},
              {"value2": "webhook", "outputKey": "Webhook"}]},
          "fallbackOutput": 1, "options": {}},
         notes="Delivers the AI reply on the originating channel.", retry=False)

add_node("Reply on Telegram", "n8n-nodes-base.telegram", 1.2, [3120, -560],
         {"resource": "message", "operation": "sendMessage",
          "chatId": "={{ $json.customerId }}",
          "text": "={{ $json.output || $json.content }}", "additionalFields": {}},
         CRED["telegramApi"], notes="Send reply via Telegram.", errorOutput=True)

add_node("Reply on WhatsApp", "n8n-nodes-base.httpRequest", 4.2, [3120, -260],
         {"method": "POST",
          "url": "https://graph.facebook.com/v19.0/{{ $env.WA_PHONE_ID }}/messages",
          "authentication": "genericCredentialType",
          "genericCredentialType": "httpHeaderAuth",
          "sendBody": True, "specifyBody": "json",
          "jsonBody": json.dumps({"messaging_product": "whatsapp",
                                  "to": "={{ $json.customerId }}",
                                  "type": "text",
                                  "text": {"body": "{{ $json.output || $json.content }}"}}),
          "options": {}},
         CRED["whatsappToken"], notes="Send reply via WhatsApp Cloud API.", errorOutput=True)

add_node("Reply on Email", "n8n-nodes-base.emailSend", 2.1, [3120, 40],
         {"fromEmail": "support@orion.internal",
          "toEmail": "={{ $json.email || $json.customerId }}",
          "subject": "Re: Your request to Orion Support",
          "emailFormat": "text",
          "message": "={{ $json.output || $json.content }}", "options": {}},
         CRED["smtp"], notes="Send reply via SMTP.", errorOutput=True)

add_node("Respond to Webhook", "n8n-nodes-base.respondToWebhook", 1, [3120, 340],
         {"responseCode": 200,
          "responseData": "={{ JSON.stringify({status:'ok', reply: $json.output || $json.content, ticket:$json.ticketId}) }}"},
         notes="Closes the Webhook/CRM event response.", retry=False)

# ==================================================================
# MONITORING / ANALYTICS
# ==================================================================
add_node("Log Analytics", "n8n-nodes-base.postgres", 2.5, [3420, -60],
         {"operation": "execute",
          "query": "INSERT INTO analytics (request_id, customer_id, channel, category, priority, response_ms, created_at) VALUES ('{{ $json.requestId }}','{{ $json.customerId }}','{{ $json.channel }}','{{ $json.category }}','{{ $json.priority }}', EXTRACT(EPOCH FROM (NOW() - '{{ $json.receivedAt }}'::timestamptz))*1000, NOW());",
          "options": {}}, CRED["postgres"],
         notes="Execution + response-time analytics sink.", errorOutput=False)

add_node("Track Response Time", "n8n-nodes-base.code", 2, [3720, -60],
         {"jsCode": "const s=$input.first().json; const ms=Math.max(0, Math.round((Date.now()-new Date(s.receivedAt).getTime()))); return [{json:{...s, responseMs:ms, slaMet: ms < 30000}}];"},
         notes="Computes end-to-end response time vs SLA.")

# ==================================================================
# ERROR HANDLING PIPELINE
# ==================================================================
add_node("Error Trigger", "n8n-nodes-base.errorTrigger", 1, [-1800, 1600],
         {}, notes="Workflow-level failure trigger (set as Error Workflow).", retry=False)

add_node("Handle Critical Error", "n8n-nodes-base.code", 2, [-1350, 1600],
         {"jsCode": "const e=$input.first().json; return [{json:{incidentTime:new Date().toISOString(), node:(e.execution||{}).lastNode||'unknown', message:(e.execution||{}).error||JSON.stringify(e), severity:'critical'}}];"},
         notes="Aggregates error outputs from critical nodes.", errorOutput=False)

add_node("Log Failure", "n8n-nodes-base.postgres", 2.5, [-1050, 1600],
         {"operation": "execute",
          "query": "INSERT INTO incidents (incident_time, node, message, severity, status) VALUES ('{{ $json.incidentTime || now() }}','{{ $json.node }}','{{ $json.message }}','{{ $json.severity || 'high' }}','open');",
          "options": {}}, CRED["postgres"],
         notes="Persists every failure to the incidents table.", errorOutput=False)

add_node("Create Incident Record", "n8n-nodes-base.postgres", 2.5, [-760, 1600],
         {"operation": "execute",
          "query": "INSERT INTO incident_records (incident_id, payload, created_at) VALUES ('INC-'+extract(epoch from now())::bigint::text,'{{ $json.message }}', NOW()) RETURNING incident_id;",
          "options": {}}, CRED["postgres"], notes="Durable incident record.", errorOutput=False)

add_node("Notify Administrator", "n8n-nodes-base.telegram", 1.2, [-470, 1600],
         {"resource": "message", "operation": "sendMessage",
          "chatId": "={{ $env.ADMIN_CHAT_ID }}",
          "text": "=🚨 Orion Alert: {{ $json.severity }} on {{ $json.node }}: {{ $json.message }}",
          "additionalFields": {}}, CRED["telegramApi"],
         notes="Alerts the on-call admin channel.", errorOutput=False)

# ==================================================================
# PAYMENT REMINDERS (scheduled, standalone)
# ==================================================================
add_node("Payment Reminders Trigger", "n8n-nodes-base.scheduleTrigger", 1.2, [-1800, 2000],
         {"rule": {"interval": [{"field": "hours", "hoursInterval": 12}]}},
         notes="Daily-ish cadence for payment reminders.", retry=False)

add_node("Send Payment Reminders", "n8n-nodes-base.emailSend", 2.1, [-1350, 2000],
         {"fromEmail": "billing@orion.internal",
          "toEmail": "={{ $json.email }}",
          "subject": "Reminder: Invoice {{ $json.invoice_id }} is overdue",
          "emailFormat": "text",
          "message": "Hi {{ $json.name }}, your invoice {{ $json.invoice_id }} ({{ $json.total }}) is {{ $json.status }}. Please complete payment. - Orion Billing",
          "options": {}}, CRED["smtp"], notes="Overdue invoice reminder (no gateway).", errorOutput=True)

# ==================================================================
# DATABASE SCHEMA SETUP (manual / one-time)
# ==================================================================
add_node("Initialize Database", "n8n-nodes-base.manualTrigger", 1, [-1800, 2400],
         {}, notes="Run once to provision the Orion schema.", retry=False)

SCHEMA_SQL = r"""
CREATE TABLE IF NOT EXISTS customers (
  customer_id TEXT PRIMARY KEY, name TEXT, phone TEXT, email TEXT,
  status TEXT DEFAULT 'active', total_orders INT DEFAULT 0, last_activity TIMESTAMPTZ);
CREATE TABLE IF NOT EXISTS messages (
  message_id BIGSERIAL PRIMARY KEY, customer_id TEXT, content TEXT,
  timestamp TIMESTAMPTZ DEFAULT NOW(), category TEXT);
CREATE TABLE IF NOT EXISTS orders (
  order_id TEXT PRIMARY KEY, customer_id TEXT, order_details JSONB, status TEXT);
CREATE TABLE IF NOT EXISTS memory (
  customer_id TEXT PRIMARY KEY, last_100_messages TEXT, updated_at TIMESTAMPTZ DEFAULT NOW());
CREATE TABLE IF NOT EXISTS knowledge_base (
  id BIGSERIAL PRIMARY KEY, faq TEXT, company_policies TEXT,
  product_information TEXT, document TSVECTOR,
  CONSTRAINT cap_1000_customers CHECK (true));
CREATE TABLE IF NOT EXISTS payments (
  payment_id TEXT, customer_id TEXT, status TEXT, amount NUMERIC, currency TEXT, paid_at TIMESTAMPTZ);
CREATE TABLE IF NOT EXISTS invoices (
  invoice_id TEXT PRIMARY KEY, customer_id TEXT, total NUMERIC, due_date DATE, status TEXT);
CREATE TABLE IF NOT EXISTS tickets (
  ticket_id TEXT PRIMARY KEY, customer_id TEXT, subject TEXT, priority TEXT,
  category TEXT, status TEXT DEFAULT 'open', created_at TIMESTAMPTZ DEFAULT NOW());
CREATE TABLE IF NOT EXISTS ticket_notes (
  id BIGSERIAL PRIMARY KEY, ticket_id TEXT, author TEXT, note TEXT, created_at TIMESTAMPTZ DEFAULT NOW());
CREATE TABLE IF NOT EXISTS incidents (
  id BIGSERIAL PRIMARY KEY, incident_time TIMESTAMPTZ, node TEXT, message TEXT, severity TEXT, status TEXT);
CREATE TABLE IF NOT EXISTS incident_records (
  incident_id TEXT PRIMARY KEY, payload TEXT, created_at TIMESTAMPTZ DEFAULT NOW());
CREATE TABLE IF NOT EXISTS analytics (
  id BIGSERIAL PRIMARY KEY, request_id TEXT, customer_id TEXT, channel TEXT,
  category TEXT, priority TEXT, response_ms INT, created_at TIMESTAMPTZ DEFAULT NOW());
CREATE INDEX IF NOT EXISTS idx_messages_customer ON messages(customer_id, timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_orders_customer ON orders(customer_id);
CREATE INDEX IF NOT EXISTS idx_kb_doc ON knowledge_base USING GIN(document);
"""

add_node("Create Database Schema", "n8n-nodes-base.postgres", 2.5, [-1350, 2400],
         {"operation": "execute", "query": SCHEMA_SQL.strip(), "options": {}},
         CRED["postgres"], notes="Idempotent DDL for all Orion tables.", retry=True)

print("Generator built", len(nodes_by_name), "nodes")

# ==================================================================
# CONNECTIONS
# ==================================================================
# Triggers -> Normalize
for t in ["Telegram Trigger", "WhatsApp Trigger", "Email Trigger", "Webhook API", "CRM Events"]:
    link(t, "Normalize Data")
link("Normalize Data", "Detect Content Type")

# Content type switch -> media pipelines
link("Detect Content Type", "Download Voice", 0)
link("Download Voice", "Speech to Text")
link("Speech to Text", "Extract Voice Intent")
link("Extract Voice Intent", "Merge Channels")

link("Detect Content Type", "Download Image", 1)
link("Download Image", "Analyze Image")
link("Analyze Image", "Merge Channels")

link("Detect Content Type", "Extract Document Text", 2)   # pdf
link("Detect Content Type", "Extract Document Text", 3)   # generic document -> same pipeline
link("Extract Document Text", "Summarize Document")
link("Summarize Document", "Merge Channels")

link("Detect Content Type", "Analyze Video", 4)            # video
link("Analyze Video", "Merge Channels")

link("Detect Content Type", "Merge Channels", 5)           # plain text fallback

# Database chain
link("Merge Channels", "Store Customer Info")
link("Store Customer Info", "Retrieve Customer Memory")
link("Retrieve Customer Memory", "Retrieve Previous Orders")
link("Retrieve Previous Orders", "Retrieve Customer History")
link("Retrieve Customer History", "Search Knowledge Base")
link("Search Knowledge Base", "Claude AI Agent")

# AI agent sub-graph
link("Claude AI Agent", "Intelligent Routing")
link_ai("Claude Chat Model", "Claude AI Agent", "ai_languageModel")
link_ai("Conversation Memory", "Claude AI Agent", "ai_memory")
link_ai("Knowledge Base Tool", "Claude AI Agent", "ai_tool")
link_ai("Order Lookup Tool", "Claude AI Agent", "ai_tool")
link_ai("Ticket Tool", "Claude AI Agent", "ai_tool")

# Routing -> 5 paths
for idx, (label, key, ly, desc) in enumerate(PATHS):
    link("Intelligent Routing", PA(label), idx)
    link(PA(label), PD(label))
    link(PD(label), SA(label))
    link(SA(label), SR(label))
    link(SR(label), "Merge Path Responses")
# fallback -> general
link("Intelligent Routing", PA("General Support"), 5)

# Post-processing
link("Merge Path Responses", "Update Memory")
link("Update Memory", "CRM: Create Ticket")
link("CRM: Create Ticket", "CRM: Store AI Notes")
link("CRM: Store AI Notes", "Verify Payment Status")
link("Verify Payment Status", "Track Invoices")
link("Track Invoices", "Select Output Channel")

# Output channels
link("Select Output Channel", "Reply on Telegram", 0)
link("Select Output Channel", "Reply on WhatsApp", 1)
link("Select Output Channel", "Reply on Email", 2)
link("Select Output Channel", "Respond to Webhook", 3)
link("Select Output Channel", "Respond to Webhook", 4)  # fallback
for r in ["Reply on Telegram", "Reply on WhatsApp", "Reply on Email", "Respond to Webhook"]:
    link(r, "Log Analytics")
link("Log Analytics", "Track Response Time")

# Error handling
link("Error Trigger", "Log Failure")
link("Handle Critical Error", "Log Failure")
link("Log Failure", "Create Incident Record")
link("Create Incident Record", "Notify Administrator")

# Critical node error outputs -> Handle Critical Error
for c in ["Speech to Text", "Analyze Image", "Extract Document Text",
          "Summarize Document", "Store Customer Info", "Retrieve Customer Memory",
          "Claude AI Agent", "CRM: Create Ticket", "Verify Payment Status"]:
    if c in nodes_by_name:
        link(c, "Handle Critical Error", 1)

# Payment reminders + schema setup
link("Payment Reminders Trigger", "Send Payment Reminders")
link("Initialize Database", "Create Database Schema")

# ==================================================================
# ASSEMBLE WORKFLOW
# ==================================================================
workflow = {
    "name": "Orion Support Hub",
    "nodes": list(nodes_by_name.values()),
    "connections": conns,
    "active": False,
    "settings": {
        "executionOrder": "v1",
        "saveExecutionProgress": True,
        "saveManualExecutions": True,
        "saveDataErrorExecution": "all",
        "saveDataSuccessExecution": "all",
        "callerPolicy": "workflowsFromSameOwner",
        "errorWorkflow": "current",
    },
    "pinData": {},
    "tags": [{"name": "AI Support"}, {"name": "Enterprise"}, {"name": "Orion"}],
    "meta": {
        "templateId": "orion-support-hub",
        "instanceId": "orion-support-hub",
        "description": "Enterprise AI customer support automation: multi-channel intake, "
                       "media processing, Claude AI agent, intelligent routing, DB memory, "
                       "CRM, payments, monitoring and resilient error handling.",
    },
}

# validate: ensure every connection target exists
missing = set()
for src, outs in conns.items():
    if src not in nodes_by_name:
        missing.add("SOURCE:" + src)
    for ctype, arr in outs.items():
        for group in arr:
            for c in group:
                if c["node"] not in nodes_by_name:
                    missing.add("TARGET:" + c["node"])
assert not missing, f"Dangling connections: {missing}"

with open("Orion_Support_Hub.json", "w") as f:
    json.dump(workflow, f, indent=2)

# re-load to confirm valid JSON
with open("Orion_Support_Hub.json") as f:
    json.load(f)

print(f"WROTE Orion_Support_Hub.json | nodes={len(nodes_by_name)} | "
      f"connection_sources={len(conns)} | valid_json=True")
