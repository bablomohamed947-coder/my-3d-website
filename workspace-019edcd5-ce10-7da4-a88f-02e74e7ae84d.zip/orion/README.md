# 🛰️ Orion Support Hub — Enterprise n8n Workflow

A production-ready, AI-powered customer-support automation platform built as a single
importable [n8n](https://n8n.io) workflow. It ingests requests from **5 channels**,
processes **6 input types**, reasons with a **Claude AI Agent**, routes across
**5 specialist paths**, persists customers/memory/orders in a database, integrates with
CRM & payment systems, and ships with resilient error handling and monitoring.

> **File:** `Orion_Support_Hub.json` — 70 nodes · 66 connection sources · 7 credential types

---

## 1. Import

1. Open n8n → **Workflows → Import from File**.
2. Select `Orion_Support_Hub.json`.
3. Configure credentials (see §3) and environment variables (see §4).
4. Run the **Initialize Database** node once to provision the schema (§5).
5. Activate the workflow.

---

## 2. Architecture (data flow)

```
 TRIGGERS                 NORMALIZE          DETECT          MEDIA PIPELINES
 ┌───────────────┐        ┌──────────┐      ┌────────┐      ┌──────────────────┐
 │ Telegram      │──┐     │          │      │        │─voice▶ Download→STT→Intent
 │ WhatsApp      │──┼────▶│ Normalize│────▶│ Switch │─image▶ Download→Analyze
 │ Email (IMAP)  │──┤     │  Data    │      │        │─doc  ▶ Extract→Summarize
 │ Webhook API   │──┤     │          │      │        │─video▶ Transcribe
 │ CRM Events    │──┘     └──────────┘      └────┬───┘      └────────┬─────────┘
                                                  └── text ───────────▶│
                                                                       ▼
                                                                  ┌─────────┐
              DATABASE LAYER (steps 7-10)                         │  Merge  │
   Store Customer ─▶ Get Memory ─▶ Get Orders ─▶ Get History ─▶ KB│Channels │
                                                                  └────┬────┘
                                                                       ▼
   ┌──────────────────────────── CLAUDE AI AGENT ───────────────────────┐
   │  Agent  ◀─ lmChatAnthropic (Claude) · Window Memory(100) · 3 Tools │
   └───────────────────────────────┬───────────────────────────────────┘
                                   ▼
                          ┌─────────────────┐
                          │ Intelligent      │  ── 5 paths ──▶
                          │ Routing (Switch) │
                          └─────────────────┘
   EACH PATH: AI Analysis → Priority Detection → Sentiment → Suggested Response
                                   ▼
        Merge ─▶ Update Memory ─▶ CRM(Ticket+Notes) ─▶ Payments(Status+Invoices)
                                   ▼
                 Select Output Channel ─▶ Telegram / WhatsApp / Email / Webhook
                                   ▼
                       Log Analytics ─▶ Track Response Time
```

**Standalone sections (run independently):**
- **Error Trigger → Log Failure → Create Incident → Notify Admin** (workflow-level resilience)
- **Payment Reminders Trigger → Send Payment Reminders** (scheduled)
- **Initialize Database → Create Database Schema** (one-time provisioning)

---

## 3. Credentials (placeholders to create in n8n)

After import, open each node and bind a real credential. The placeholders use stable IDs/names:

| Credential type | Placeholder name | Used by |
|---|---|---|
| `telegramApi` | Orion Telegram Bot | Telegram Trigger, Reply on Telegram, Notify Administrator |
| `anthropicApi` | Orion Claude API Key | AI Agent (20 Claude HTTP/Model nodes) |
| `openAiApi` | Orion OpenAI API Key | Speech to Text, Analyze Video (Whisper) |
| `postgres` | Orion PostgreSQL Database | All DB / analytics / incident nodes (12) |
| `smtp` | Orion SMTP Outbound | Reply on Email, Send Payment Reminders |
| `imap` | Orion Support IMAP Inbox | Email Trigger |
| `httpHeaderAuth` | Orion WhatsApp Cloud API / Orion CRM API | WhatsApp reply, CRM ticket + notes (Bearer tokens) |

---

## 4. Environment variables

| Variable | Purpose |
|---|---|
| `WA_PHONE_ID` | WhatsApp Business phone number ID |
| `ADMIN_CHAT_ID` | Telegram chat/channel for admin alerts |

---

## 5. Database schema

Run **Initialize Database** once — it executes idempotent `CREATE TABLE IF NOT EXISTS` DDL:

- **customers** — `customer_id, name, phone, email, status, total_orders, last_activity`
- **messages** — `message_id, customer_id, content, timestamp, category`
- **orders** — `order_id, customer_id, order_details(JSONB), status`
- **memory** — `customer_id, last_100_messages, updated_at`
- **knowledge_base** — `faq, company_policies, product_information, document(TSVECTOR)`
- **payments** — `payment_id, customer_id, status, amount, currency, paid_at`
- **invoices** — `invoice_id, customer_id, total, due_date, status`
- **tickets** — `ticket_id, customer_id, subject, priority, category, status, created_at`
- **ticket_notes** — `ticket_id, author, note, created_at`
- **incidents** / **incident_records** — error log + durable incident store
- **analytics** — `request_id, channel, category, priority, response_ms, created_at`

Indexes on `messages(customer_id,timestamp)`, `orders(customer_id)`, and a GIN index
on the knowledge-base `document` vector are created automatically.

### Memory rules
- Rolling **last-100-message** window per customer (Window Buffer Memory, sessionId = customer_id).
- Memory row upserted/appended after every interaction via **Update Memory**.
- `messages` table retains full history (suitable for 1000+ customers).

---

## 6. The 5 intelligent paths

| # | Path | Category | Specialty |
|---|---|---|---|
| 1 | General Support | `general` | FAQs, account, how-to |
| 2 | Sales | `sales` | Pricing, plans, demos, quotes |
| 3 | Technical | `technical` | Bugs, errors, integrations, steps |
| 4 | Billing And Payments | `billing` | Invoices, refunds, subscriptions |
| 5 | Complaints And Escalations | `complaints` | De-escalation, SLA/escalation flags |

Each path contains: **AI Analysis** (Claude) → **Priority Detection** (rule engine, P1/P2/P3) →
**Sentiment Analysis** (Claude) → **Suggested Response** (Claude).

---

## 7. Error handling & resilience

- **Auto-retry:** every critical node has `retryOnFail=true, maxTries=5, waitBetweenTries=5000ms`.
- **Error outputs:** critical nodes use `continueErrorOutput` → routed to **Handle Critical Error**.
- **Failure pipeline:** Handle Critical Error / Error Trigger → **Log Failure** → **Create Incident Record** → **Notify Administrator** (Telegram).
- **Workflow setting:** `errorWorkflow` is enabled; set this file (or a copy) as the instance Error Workflow for top-level crashes.

---

## 8. Monitoring & security

- **Execution logs:** `saveExecutionProgress`, `saveDataSuccess/ErrorExecution = all`.
- **Analytics:** every request is written to `analytics` with channel, category, priority.
- **Response-time SLA:** `Track Response Time` computes end-to-end ms vs a 30 s SLA.
- **Input sanitization/validation:** the **Normalize Data** Code node coerces, types and defaults all inbound fields before they touch the DB or AI.
- **Secure credentials:** all secrets stored as n8n credentials (placeholders); no keys in the JSON.
- **Error isolation:** each branch is independent; a failure in one media pipeline does not block others.

---

## 9. Notes & customization

- The WhatsApp/CRM/KB endpoints use illustrative internal URLs (`*.orion.internal`) and the WhatsApp Graph API — replace with your hosts.
- Knowledge-base search uses Postgres `tsvector`; swap for a vector DB + embeddings tool for semantic search.
- The payment system is intentionally **read-only** (no gateway connection) per spec.
- Claude model defaults to `claude-sonnet-4-5-20250929`; adjust in `Claude Chat Model` and the HTTP nodes if needed.
